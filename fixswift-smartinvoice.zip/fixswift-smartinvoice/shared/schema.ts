import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull(),
  logo: text("logo"),
  businessDetails: text("business_details"),
  clientDetails: text("client_details"),
  paymentTerms: text("payment_terms").notNull(),
  issueDate: timestamp("issue_date").notNull(),
  dueDate: timestamp("due_date").notNull(),
  currency: text("currency").notNull(),
  subtotal: text("subtotal"),
  discountTotal: text("discount_total"),
  // GST fields for Indian tax compliance
  gstNumber: text("gst_number"),
  gstType: text("gst_type"), // 'cgst_sgst' (intra-state) or 'igst' (inter-state)
  gstRate: text("gst_rate"),
  cgstValue: text("cgst_value"),
  sgstValue: text("sgst_value"),
  igstValue: text("igst_value"),
  shipping: text("shipping"),
  total: text("total"),
  paymentMethod: text("payment_method"),
  items: jsonb("items"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const invoiceInsertSchema = createInsertSchema(invoices, {
  invoiceNumber: (schema) => schema.min(1, "Invoice number is required"),
  paymentTerms: (schema) => schema.min(1, "Payment terms are required"),
  currency: (schema) => schema.min(1, "Currency is required"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = typeof invoices.$inferInsert;
