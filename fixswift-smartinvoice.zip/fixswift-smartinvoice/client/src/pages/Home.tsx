import { useState } from "react";
import { InvoiceForm } from "@/components/invoice/InvoiceForm";
import { InvoicePreview } from "@/components/invoice/InvoicePreview";
import { InvoiceLayout } from "@/components/invoice/InvoiceLayout";
import { Link } from "wouter";
import { ArrowRight, FileText, SendHorizontal, Download, Clock, PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [showInvoiceForm, setShowInvoiceForm] = useState(false);

  const handleOpenPreview = () => {
    setIsPreviewOpen(true);
  };

  const handleCreateInvoice = () => {
    setShowInvoiceForm(true);
    // Smooth scroll to invoice form
    window.scrollTo({
      top: document.getElementById('invoice-form')?.offsetTop || 0,
      behavior: 'smooth'
    });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      {!showInvoiceForm && (
        <>
          <div className="relative overflow-hidden">
            <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8 flex flex-col items-center text-center">
              <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">
                Professional invoices made simple
              </h1>
              <p className="mt-6 text-lg leading-8 text-gray-600 max-w-2xl">
                Create and manage beautiful, customizable invoices for your clients in seconds. No sign-up required.
              </p>
              <div className="mt-10 flex items-center justify-center gap-x-6">
                <Button 
                  onClick={handleCreateInvoice}
                  className="rounded-md bg-blue-600 px-5 py-6 text-md font-semibold text-white shadow-sm hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 flex items-center"
                >
                  Create Invoice <PlusCircle className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Features */}
          <div className="bg-gray-50 py-20">
            <div className="mx-auto max-w-7xl px-6 lg:px-8">
              <div className="mx-auto max-w-2xl text-center">
                <h2 className="text-3xl font-bold tracking-tight text-gray-900">
                  Everything you need to manage your invoices
                </h2>
                <p className="mt-6 text-lg leading-8 text-gray-600">
                  Fixswift SmartInvoice simplifies billing and helps you maintain a professional image.
                </p>
              </div>
              <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-5xl">
                <div className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-10 lg:max-w-none lg:grid-cols-3 lg:gap-y-16">
                  <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100">
                      <FileText className="h-6 w-6 text-blue-600" />
                    </div>
                    <h3 className="mt-4 text-lg font-semibold leading-7 text-gray-900">Customizable Templates</h3>
                    <p className="mt-2 text-base leading-7 text-gray-600">
                      Create beautiful, professional invoices that reflect your brand identity.
                    </p>
                  </div>
                  <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100">
                      <SendHorizontal className="h-6 w-6 text-blue-600" />
                    </div>
                    <h3 className="mt-4 text-lg font-semibold leading-7 text-gray-900">Multiple Export Options</h3>
                    <p className="mt-2 text-base leading-7 text-gray-600">
                      Download as PDF, send via email, or generate shareable links for your clients.
                    </p>
                  </div>
                  <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100">
                      <Clock className="h-6 w-6 text-blue-600" />
                    </div>
                    <h3 className="mt-4 text-lg font-semibold leading-7 text-gray-900">Time-Saving Features</h3>
                    <p className="mt-2 text-base leading-7 text-gray-600">
                      Real-time calculations, tax handling, and multi-currency support built-in.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="bg-white py-16">
            <div className="mx-auto max-w-7xl px-6 lg:px-8">
              <div className="mx-auto max-w-2xl text-center">
                <h2 className="text-3xl font-bold tracking-tight text-gray-900">
                  Ready to create your first invoice?
                </h2>
                <p className="mt-6 text-lg leading-8 text-gray-600">
                  It only takes a few minutes to generate a professional invoice for your clients.
                </p>
                <div className="mt-10 flex items-center justify-center">
                  <Button 
                    onClick={handleCreateInvoice}
                    className="rounded-md bg-blue-600 px-5 py-6 text-md font-semibold text-white shadow-sm hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 flex items-center"
                  >
                    Start Now <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Invoice Form with Layout */}
      <div id="invoice-form" className={showInvoiceForm ? '' : 'hidden'}>
        <div className="bg-white border-b border-gray-200 px-4 py-3 sm:px-6 flex items-center justify-between sticky top-0 z-10">
          <h2 className="text-xl font-semibold text-gray-900">Create Invoice</h2>
          {showInvoiceForm && (
            <Button 
              variant="outline" 
              onClick={() => setShowInvoiceForm(false)}
              className="text-gray-700"
            >
              Back to Home
            </Button>
          )}
        </div>
        
        <div className="invoice-app-container">
          <InvoiceLayout 
            invoiceForm={<InvoiceForm onPreview={handleOpenPreview} />} 
            onPreview={handleOpenPreview}
          />
        </div>
      </div>

      {/* Invoice Preview */}
      <InvoicePreview 
        open={isPreviewOpen} 
        onOpenChange={setIsPreviewOpen} 
      />
    </div>
  );
}
