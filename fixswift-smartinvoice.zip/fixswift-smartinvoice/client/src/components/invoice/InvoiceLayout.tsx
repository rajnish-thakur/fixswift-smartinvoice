import React, { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Eye } from "lucide-react";
import { useMobile } from "@/hooks/use-mobile";

interface InvoiceLayoutProps {
  invoiceForm: ReactNode;
  onPreview: () => void;
}

export function InvoiceLayout({ invoiceForm, onPreview }: InvoiceLayoutProps) {
  const { isMobile } = useMobile();

  return (
    <div className="max-w-[1200px] mx-auto p-4">
      <div className="relative">
        {/* Invoice Form */}
        <div className="w-full">
          {invoiceForm}
          
          {/* Preview Button */}
          <div className="mt-6 mb-4 flex justify-center">
            <Button
              type="button"
              onClick={onPreview}
              className="bg-blue-600 hover:bg-blue-700 flex items-center justify-center gap-2"
            >
              <Eye className="h-4 w-4" />
              Preview Invoice
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}