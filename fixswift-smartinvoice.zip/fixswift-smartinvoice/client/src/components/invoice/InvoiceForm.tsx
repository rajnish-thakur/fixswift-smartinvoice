import { useState, useRef, useEffect } from "react";
import { useForm, FormProvider } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Trash2, 
  Plus, 
  Building2, 
  CreditCard, 
  Smartphone, 
  Link, 
  Banknote, 
  Pencil, 
  FileText, 
  Calendar as CalendarIcon, 
  Image, 
  Receipt, 
  CircleDollarSign, 
  CircleUser,
  Upload, 
  Hash, 
  AlertCircle, 
  Eye 
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Calendar } from "@/components/ui/calendar";
import { ToggleSection } from "@/components/ui/toggle-section";
import { InvoiceItem as InvoiceItemComponent } from "@/components/invoice/InvoiceItem";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { CURRENCIES } from "@/lib/currencies";
import { useInvoiceStore } from "@/lib/invoice-utils";

// Define invoice line item schema
const invoiceItemSchema = z.object({
  id: z.string(),
  description: z.string().optional(),
  quantity: z.number().min(0).default(1),
  rate: z.number().min(0).default(0),
  discount: z.number().min(0).max(100).default(0),
  amount: z.number().min(0).default(0),
});

// Type for invoice line item
type InvoiceItem = z.infer<typeof invoiceItemSchema>;

// Form validation schema
const formSchema = z.object({
  invoiceNumber: z.string().min(1, { message: "Invoice number is required" }),
  paymentTerms: z.string().min(1, { message: "Payment terms are required" }),
  issueDate: z.date({ required_error: "Issue date is required" }),
  dueDate: z.date({ required_error: "Due date is required" }),
  currency: z.string().min(1, { message: "Currency is required" }),
  // Business details
  businessDetails: z.string().optional(),
  // Client details
  clientDetails: z.string().optional(),
  // Invoice items
  items: z.array(invoiceItemSchema).default([]),
  // Additional calculations
  subtotal: z.number().default(0),
  discountTotal: z.number().min(0).max(100).default(0),
  // Indian GST details
  gstType: z.enum(["igst", "cgst_sgst"]).default("cgst_sgst"),
  gstNumber: z.string().optional(),
  gstRate: z.number().min(0).max(28).default(18),
  cgstValue: z.number().default(0),
  sgstValue: z.number().default(0),
  igstValue: z.number().default(0),
  shipping: z.number().min(0).default(0),
  total: z.number().default(0),
  // Payment details
  paymentMethod: z.string().optional(),
});

// Type for invoice form data
type InvoiceFormValues = z.infer<typeof formSchema>;

interface InvoiceFormProps {
  onPreview: () => void;
}

export function InvoiceForm({ onPreview }: InvoiceFormProps) {
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { setInvoiceData } = useInvoiceStore();

  // Initialize form with default values
  const form = useForm<InvoiceFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      invoiceNumber: "",
      paymentTerms: "",
      issueDate: new Date(),
      dueDate: new Date(),
      currency: "INR",
      gstType: "cgst_sgst",
      gstNumber: "",
      gstRate: 18,
      businessDetails: "",
      clientDetails: "",
      items: [
        {
          id: crypto.randomUUID(),
          description: "",
          quantity: 1,
          rate: 0,
          discount: 0,
          amount: 0,
        },
      ],
      subtotal: 0,
      discountTotal: 0,
      shipping: 0,
      total: 0,
      cgstValue: 0,
      sgstValue: 0,
      igstValue: 0,
    },
  });

  // Update due date when payment terms or issue date changes
  const watchIssueDate = form.watch("issueDate");
  const watchPaymentTerms = form.watch("paymentTerms");

  useEffect(() => {
    if (watchIssueDate && watchPaymentTerms) {
      const issueDate = new Date(watchIssueDate);
      let dueDate = new Date(issueDate);

      switch (watchPaymentTerms) {
        case "net7":
          dueDate.setDate(issueDate.getDate() + 7);
          break;
        case "net15":
          dueDate.setDate(issueDate.getDate() + 15);
          break;
        case "net30":
          dueDate.setDate(issueDate.getDate() + 30);
          break;
        case "net45":
          dueDate.setDate(issueDate.getDate() + 45);
          break;
        case "net60":
          dueDate.setDate(issueDate.getDate() + 60);
          break;
        case "due_on_receipt":
          // Due date is same as issue date
          break;
      }

      form.setValue("dueDate", dueDate);
    }
  }, [watchIssueDate, watchPaymentTerms, form]);

  // Handle logo file changes
  const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast({
          variant: "destructive",
          title: "Invalid file type",
          description: "Please upload an image file (JPEG, PNG, GIF).",
        });
        return;
      }
      
      // Validate file size (2MB max)
      if (file.size > 2 * 1024 * 1024) {
        toast({
          variant: "destructive",
          title: "File too large",
          description: "File size must be less than 2MB.",
        });
        return;
      }

      setLogoFile(file);
      
      // Create a preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle logo drop
  const handleLogoDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    if (event.dataTransfer.files && event.dataTransfer.files[0]) {
      const file = event.dataTransfer.files[0];
      
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast({
          variant: "destructive",
          title: "Invalid file type",
          description: "Please upload an image file (JPEG, PNG, GIF).",
        });
        return;
      }
      
      // Validate file size (2MB max)
      if (file.size > 2 * 1024 * 1024) {
        toast({
          variant: "destructive",
          title: "File too large",
          description: "File size must be less than 2MB.",
        });
        return;
      }

      setLogoFile(file);
      
      // Create a preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle logo drag events
  const handleLogoDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  };
  
  // Format currency helper function
  const formatCurrency = (amount: number, currencyCode: string): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currencyCode,
    }).format(amount);
  };
  
  // Watch for changes in invoice items
  const watchItems = form.watch("items");
  const watchDiscountTotal = form.watch("discountTotal");
  const watchGstType = form.watch("gstType");
  const watchGstRate = form.watch("gstRate");
  const watchShipping = form.watch("shipping");
  
  // Calculate item amount when quantity, rate, or discount changes
  const calculateItemAmount = (item: InvoiceItem): number => {
    const quantity = item.quantity || 0;
    const rate = item.rate || 0;
    const discount = item.discount || 0;
    
    const amount = quantity * rate;
    const discountAmount = amount * (discount / 100);
    
    return parseFloat((amount - discountAmount).toFixed(2));
  };
  
  // Recalculate totals when items change
  useEffect(() => {
    if (watchItems) {
      // Update each item's amount based on quantity, rate, and discount
      const updatedItems = watchItems.map(item => ({
        ...item,
        amount: calculateItemAmount(item)
      }));
      
      // Calculate subtotal (sum of all item amounts)
      const subtotal = updatedItems.reduce((sum, item) => sum + (item.amount || 0), 0);
      
      // Calculate discount total amount
      const discountTotalAmount = subtotal * (watchDiscountTotal / 100);
      
      // Calculate GST amounts for Indian taxation
      const taxableAmount = subtotal - discountTotalAmount;
      let cgstValue = 0;
      let sgstValue = 0;
      let igstValue = 0;
      
      if (watchGstType === "cgst_sgst") {
        // For intra-state supply: Split GST into CGST and SGST (half each)
        cgstValue = taxableAmount * (watchGstRate / 2 / 100);
        sgstValue = taxableAmount * (watchGstRate / 2 / 100);
      } else {
        // For inter-state supply: Apply full GST as IGST
        igstValue = taxableAmount * (watchGstRate / 100);
      }
      
      // Total tax amount is the sum of all GST components
      const totalTaxAmount = cgstValue + sgstValue + igstValue;
      
      // Calculate total
      const total = taxableAmount + totalTaxAmount + (watchShipping || 0);
      
      // Update form values
      form.setValue("items", updatedItems);
      form.setValue("subtotal", parseFloat(subtotal.toFixed(2)));
      form.setValue("cgstValue", parseFloat(cgstValue.toFixed(2)));
      form.setValue("sgstValue", parseFloat(sgstValue.toFixed(2)));
      form.setValue("igstValue", parseFloat(igstValue.toFixed(2)));
      form.setValue("total", parseFloat(total.toFixed(2)));
    }
  }, [watchItems, watchDiscountTotal, watchGstRate, watchGstType, watchShipping, form]);
  
  // Add a new invoice item
  const addInvoiceItem = () => {
    const currentItems = form.getValues("items") || [];
    
    form.setValue("items", [
      ...currentItems,
      {
        id: crypto.randomUUID(),
        description: "",
        quantity: 1,
        rate: 0,
        discount: 0,
        amount: 0
      }
    ]);
  };
  
  // Remove an invoice item
  const removeInvoiceItem = (id: string) => {
    const currentItems = form.getValues("items") || [];
    
    if (currentItems.length === 1) {
      // Don't remove the last item
      toast({
        title: "Cannot remove item",
        description: "You must have at least one invoice item.",
        variant: "destructive"
      });
      return;
    }
    
    form.setValue(
      "items",
      currentItems.filter(item => item.id !== id)
    );
  };

  // Handle form submission
  const onSubmit = async (data: InvoiceFormValues) => {
    try {
      setIsSubmitting(true);
      
      // Store invoice data in global state for the preview
      setInvoiceData({
        ...data,
        logo: logoPreview,
        issueDate: format(data.issueDate, "yyyy-MM-dd"),
        dueDate: format(data.dueDate, "yyyy-MM-dd"),
      });

      // Optionally trigger preview
      onPreview();
      
      setIsSubmitting(false);
    } catch (error) {
      console.error("Error submitting form:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "There was a problem submitting the form. Please try again.",
      });
      setIsSubmitting(false);
    }
  };

  // Handle invoice generation
  const handleGeneratePDF = async () => {
    if (!form.formState.isValid) {
      form.trigger();
      return;
    }

    try {
      setIsSubmitting(true);
      
      const formData = new FormData();
      const values = form.getValues();
      
      formData.append("invoiceNumber", values.invoiceNumber);
      formData.append("paymentTerms", values.paymentTerms);
      formData.append("issueDate", format(values.issueDate, "yyyy-MM-dd"));
      formData.append("dueDate", format(values.dueDate, "yyyy-MM-dd"));
      formData.append("currency", values.currency);
      formData.append("businessDetails", values.businessDetails || "");
      formData.append("clientDetails", values.clientDetails || "");
      formData.append("subtotal", values.subtotal.toString());
      formData.append("discountTotal", values.discountTotal.toString());
      formData.append("gstRate", values.gstRate.toString());
      formData.append("gstType", values.gstType);
      if (values.gstNumber) {
        formData.append("gstNumber", values.gstNumber);
      }
      formData.append("cgstValue", values.cgstValue.toString());
      formData.append("sgstValue", values.sgstValue.toString());
      formData.append("igstValue", values.igstValue.toString());
      formData.append("shipping", values.shipping.toString());
      formData.append("total", values.total.toString());
      formData.append("paymentMethod", values.paymentMethod || "");
      
      // Add items data as JSON
      formData.append("items", JSON.stringify(values.items));
      
      if (logoFile) {
        formData.append("logo", logoFile);
      }
      
      const response = await fetch("/api/invoices", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to create invoice");
      }
      
      // Get the created invoice data
      const invoice = await response.json();
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      
      // Show success message
      toast({
        title: "Success",
        description: "Invoice PDF generated successfully!",
      });
      
      // Redirect to download the PDF
      window.open(`/api/invoices/${invoice.id}/download`, "_blank");
      
      setIsSubmitting(false);
    } catch (error) {
      console.error("Error generating PDF:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "There was a problem generating the PDF. Please try again.",
      });
      setIsSubmitting(false);
    }
  };

  // Render InvoiceForm UI
  return (
    <div className="bg-white">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Logo Upload */}
          <ToggleSection 
            title="Your Logo" 
            icon={<Image className="h-5 w-5" />}
            defaultOpen={false}
          >
            <div 
              className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center bg-gray-50 cursor-pointer transition-colors hover:bg-gray-100"
              onDrop={handleLogoDrop}
              onDragOver={handleLogoDragOver}
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                type="file"
                accept="image/*"
                className="hidden"
                ref={fileInputRef}
                onChange={handleLogoChange}
              />
              
              {logoPreview ? (
                <div className="relative w-full max-w-[200px] mb-4">
                  <img 
                    src={logoPreview} 
                    alt="Logo Preview" 
                    className="w-full h-auto object-contain" 
                  />
                  <Button 
                    type="button" 
                    variant="destructive" 
                    size="sm" 
                    className="absolute -top-2 -right-2 rounded-full p-1 h-7 w-7"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLogoFile(null);
                      setLogoPreview(null);
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center">
                  <div className="mb-3 p-3 rounded-full bg-blue-100">
                    <Building2 className="h-7 w-7 text-blue-600" />
                  </div>
                  <div className="mb-2 text-sm font-medium text-gray-900">Upload Your Logo</div>
                  <div className="text-xs text-gray-500">Drag and drop or click to browse</div>
                </div>
              )}
            </div>
          </ToggleSection>
          
          {/* Invoice Details */}
          <ToggleSection 
            title="Invoice Information" 
            icon={<Receipt className="h-5 w-5" />}
          >
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Invoice Number */}
                <FormField
                  control={form.control}
                  name="invoiceNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Invoice Number</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-500">
                            <Hash className="h-4 w-4" />
                          </span>
                          <Input
                            className="pl-9 focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
                            placeholder="INV-001"
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Payment Terms */}
                <FormField
                  control={form.control}
                  name="paymentTerms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Payment Terms</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="focus:border-blue-400 focus:ring-1 focus:ring-blue-200">
                            <SelectValue placeholder="Select payment terms" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="due_on_receipt">Due on Receipt</SelectItem>
                          <SelectItem value="net7">Net 7 Days</SelectItem>
                          <SelectItem value="net15">Net 15 Days</SelectItem>
                          <SelectItem value="net30">Net 30 Days</SelectItem>
                          <SelectItem value="net45">Net 45 Days</SelectItem>
                          <SelectItem value="net60">Net 60 Days</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Issue Date */}
                <FormField
                  control={form.control}
                  name="issueDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel className="text-gray-700">Issue Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal focus:border-blue-400 focus:ring-1 focus:ring-blue-200",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Due Date */}
                <FormField
                  control={form.control}
                  name="dueDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel className="text-gray-700">Due Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal focus:border-blue-400 focus:ring-1 focus:ring-blue-200",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                      <FormDescription className="text-xs">
                        Auto-calculated based on issue date and payment terms
                      </FormDescription>
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Currency (Fixed to INR for Indian users) */}
              <FormField
                control={form.control}
                name="currency"
                render={({ field }) => {
                  // Set currency to INR by default
                  useEffect(() => {
                    field.onChange("INR");
                  }, [field]);
                  
                  return (
                    <FormItem>
                      <FormLabel className="text-gray-700">Currency</FormLabel>
                      <FormControl>
                        <div className="h-10 px-3 py-2 rounded-md border border-input bg-background flex items-center">
                          <span className="text-gray-700">INR - Indian Rupee (₹)</span>
                        </div>
                      </FormControl>
                      <FormDescription className="text-xs text-gray-500">
                        Currency is set to Indian Rupee (₹) for Indian billing
                      </FormDescription>
                    </FormItem>
                  );
                }}
              />
            </div>
          </ToggleSection>
          
          {/* From / To Section */}
          <ToggleSection 
            title="Business & Client Information" 
            icon={<CircleUser className="h-5 w-5" />}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Business Details */}
              <FormField
                control={form.control}
                name="businessDetails"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">
                      <div className="flex items-center mb-1">
                        <Building2 className="h-4 w-4 mr-1 text-gray-500" />
                        Your Business Details
                      </div>
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Your Name / Business Name&#10;Address&#10;Phone / Email&#10;Tax ID / Business Number"
                        className="min-h-[120px] focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Client Details */}
              <FormField
                control={form.control}
                name="clientDetails"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">
                      <div className="flex items-center mb-1">
                        <Smartphone className="h-4 w-4 mr-1 text-gray-500" />
                        Client Details
                      </div>
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Client Name&#10;Address&#10;Phone / Email&#10;Tax ID (if applicable)"
                        className="min-h-[120px] focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </ToggleSection>
          
          {/* Invoice Items */}
          <ToggleSection 
            title="Invoice Items" 
            icon={<Receipt className="h-5 w-5" />}
          >
            <div className="space-y-4">
              <div className="flex justify-end mb-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addInvoiceItem}
                  className="text-sm"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Item
                </Button>
              </div>
              
              <FormProvider {...form}>
                <div className="space-y-2">
                  {form.watch("items").map((item, index) => (
                    <InvoiceItemComponent
                      key={item.id}
                      index={index}
                      currency={form.watch("currency")}
                      onRemove={() => removeInvoiceItem(item.id)}
                    />
                  ))}
                </div>
              </FormProvider>
              
              <div className="bg-white p-4 rounded-lg border border-gray-200 mt-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-700">Subtotal:</span>
                    <span className="font-medium">{formatCurrency(form.watch("subtotal"), form.watch("currency"))}</span>
                  </div>
                  {form.watch("discountTotal") > 0 && (
                    <div className="flex justify-between text-red-600">
                      <span>Discount ({form.watch("discountTotal")}%):</span>
                      <span>-{formatCurrency(form.watch("subtotal") * (form.watch("discountTotal") / 100), form.watch("currency"))}</span>
                    </div>
                  )}
                  {form.watch("gstRate") > 0 && form.watch("gstType") === "cgst_sgst" && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-gray-700">CGST ({form.watch("gstRate")/2}%):</span>
                        <span>{formatCurrency((form.watch("subtotal") - (form.watch("subtotal") * (form.watch("discountTotal") / 100))) * (form.watch("gstRate") / 2 / 100), form.watch("currency"))}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-700">SGST ({form.watch("gstRate")/2}%):</span>
                        <span>{formatCurrency((form.watch("subtotal") - (form.watch("subtotal") * (form.watch("discountTotal") / 100))) * (form.watch("gstRate") / 2 / 100), form.watch("currency"))}</span>
                      </div>
                    </>
                  )}
                  {form.watch("gstRate") > 0 && form.watch("gstType") === "igst" && (
                    <div className="flex justify-between">
                      <span className="text-gray-700">IGST ({form.watch("gstRate")}%):</span>
                      <span>{formatCurrency((form.watch("subtotal") - (form.watch("subtotal") * (form.watch("discountTotal") / 100))) * (form.watch("gstRate") / 100), form.watch("currency"))}</span>
                    </div>
                  )}
                  {form.watch("shipping") > 0 && (
                    <div className="flex justify-between">
                      <span className="text-gray-700">Shipping:</span>
                      <span>{formatCurrency(form.watch("shipping"), form.watch("currency"))}</span>
                    </div>
                  )}
                  <div className="border-t pt-2 mt-2 flex justify-between text-lg font-semibold">
                    <span>Total:</span>
                    <span className="text-blue-600">{formatCurrency(form.watch("total"), form.watch("currency"))}</span>
                  </div>
                </div>
              </div>
            </div>
          </ToggleSection>
          
          {/* Invoice Totals */}
          <ToggleSection 
            title="GST, Discount & Shipping" 
            icon={<CircleDollarSign className="h-5 w-5" />}
            defaultOpen={false}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <FormField
                  control={form.control}
                  name="discountTotal"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Discount (%)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="0"
                          max="100"
                          className="focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
                          {...field}
                          onChange={e => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="space-y-6">
                <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
                  <h4 className="text-blue-800 font-medium mb-1">GST Information for Indian Invoices</h4>
                  <p className="text-sm text-blue-700">
                    For Indian businesses, GST details are required on invoices. 
                    Intra-state transactions use CGST & SGST (split equally), while 
                    inter-state transactions use IGST.
                  </p>
                </div>
                {/* GST Number */}
                <FormField
                  control={form.control}
                  name="gstNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">GST Number (GSTIN)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="22AAAAA0000A1Z5"
                          className="focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription className="text-xs">
                        Enter your 15-digit GST Identification Number
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* GST Type */}
                <FormField
                  control={form.control}
                  name="gstType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">GST Type</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="focus:border-blue-400 focus:ring-1 focus:ring-blue-200">
                            <SelectValue placeholder="Select GST type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="cgst_sgst">CGST & SGST (Intra-state)</SelectItem>
                          <SelectItem value="igst">IGST (Inter-state)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription className="text-xs">
                        Select CGST & SGST for same-state transactions, IGST for different states
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* GST Rate (%) */}
                <FormField
                  control={form.control}
                  name="gstRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">GST Rate (%)</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))} 
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger className="focus:border-blue-400 focus:ring-1 focus:ring-blue-200">
                            <SelectValue placeholder="Select GST rate" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="0">0% - GST Exempt</SelectItem>
                          <SelectItem value="5">5% - Basic services</SelectItem>
                          <SelectItem value="12">12% - Standard rate</SelectItem>
                          <SelectItem value="18">18% - Standard rate</SelectItem>
                          <SelectItem value="28">28% - Luxury goods</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription className="text-xs">
                        Common GST rates in India per service/product category
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            <div className="mt-4">
              <FormField
                control={form.control}
                name="shipping"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700">Shipping ({CURRENCIES.find(c => c.code === form.watch("currency"))?.symbol || "$"})</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        className="focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
                        {...field}
                        onChange={e => field.onChange(parseFloat(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </ToggleSection>
          
          {/* Payment Method */}
          <ToggleSection 
            title="Payment Details" 
            icon={<CreditCard className="h-5 w-5" />}
            defaultOpen={false}
          >
            <FormField
              control={form.control}
              name="paymentMethod"
              render={({ field }) => (
                <FormItem>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id="payMethod1"
                        value="bank_transfer"
                        checked={field.value === "bank_transfer"}
                        onChange={() => field.onChange("bank_transfer")}
                        className="h-4 w-4 text-blue-500 border-gray-300 focus:ring-blue-500"
                      />
                      <label htmlFor="payMethod1" className="text-sm font-medium text-gray-700">Bank Transfer</label>
                    </div>
                    {field.value === "bank_transfer" && (
                      <div className="ml-6 p-3 bg-gray-50 rounded-md border border-gray-200">
                        <Textarea 
                          placeholder="Bank: [Your Bank Name]&#10;Account Name: [Your Name]&#10;Account Number: [Your Account Number]&#10;Routing/Sort Code: [Code]&#10;SWIFT/BIC: [If applicable]"
                          className="resize-none border-gray-200 focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
                          rows={5}
                        />
                      </div>
                    )}
                    
                    <div className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id="payMethod2"
                        value="paypal"
                        checked={field.value === "paypal"}
                        onChange={() => field.onChange("paypal")}
                        className="h-4 w-4 text-blue-500 border-gray-300 focus:ring-blue-500"
                      />
                      <label htmlFor="payMethod2" className="text-sm font-medium text-gray-700">PayPal</label>
                    </div>
                    {field.value === "paypal" && (
                      <div className="ml-6 p-3 bg-gray-50 rounded-md border border-gray-200">
                        <Input 
                          placeholder="your.email@example.com" 
                          className="border-gray-200 focus:border-blue-400 focus:ring-1 focus:ring-blue-200" 
                        />
                      </div>
                    )}
                    
                    <div className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id="payMethod3"
                        value="stripe"
                        checked={field.value === "stripe"}
                        onChange={() => field.onChange("stripe")}
                        className="h-4 w-4 text-blue-500 border-gray-300 focus:ring-blue-500"
                      />
                      <label htmlFor="payMethod3" className="text-sm font-medium text-gray-700">Stripe</label>
                    </div>
                    {field.value === "stripe" && (
                      <div className="ml-6 p-3 bg-gray-50 rounded-md border border-gray-200">
                        <Input 
                          placeholder="Stripe Link URL" 
                          className="border-gray-200 focus:border-blue-400 focus:ring-1 focus:ring-blue-200" 
                        />
                      </div>
                    )}
                    
                    <div className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id="payMethod4"
                        value="other"
                        checked={field.value === "other"}
                        onChange={() => field.onChange("other")}
                        className="h-4 w-4 text-blue-500 border-gray-300 focus:ring-blue-500"
                      />
                      <label htmlFor="payMethod4" className="text-sm font-medium text-gray-700">Other</label>
                    </div>
                    {field.value === "other" && (
                      <div className="ml-6 p-3 bg-gray-50 rounded-md border border-gray-200">
                        <Textarea 
                          placeholder="Specify payment details here..." 
                          className="resize-none border-gray-200 focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
                          rows={3}
                        />
                      </div>
                    )}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </ToggleSection>
          
          {/* Action Buttons */}
          <div className="flex justify-end space-x-4 pt-4">
            <Button
              type="button"
              variant="outline"
              className="gap-2"
              onClick={() => {
                form.trigger();
                onPreview();
              }}
            >
              <Eye className="h-4 w-4" />
              Preview
            </Button>
            <Button 
              type="submit" 
              className="bg-blue-600 hover:bg-blue-700 gap-2"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <span className="animate-spin">
                    <svg className="h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  </span>
                  Processing...
                </>
              ) : (
                <>
                  <FileText className="h-4 w-4" />
                  Generate Invoice
                </>
              )}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}