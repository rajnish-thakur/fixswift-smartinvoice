import React from 'react';
import {
  Download,
  Copy,
  Printer,
  Mail,
  FileSpreadsheet,
  Image,
  Share2,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { InvoiceData } from '@/lib/invoice-utils';

interface ExportActionsProps {
  invoiceData: InvoiceData | null;
  onDownloadPdf: () => void;
}

export function ExportActions({ invoiceData, onDownloadPdf }: ExportActionsProps) {
  // Mock functions for demo purposes
  const handleCopyLink = () => {
    // Copy a shareable link to clipboard
    navigator.clipboard.writeText(`https://fixswift.com/invoice/share/${Math.random().toString(36).substring(2, 15)}`);
    alert('Link copied to clipboard!');
  };

  const handlePrint = () => {
    window.print();
  };
  
  const handleEmail = () => {
    const subject = `Invoice ${invoiceData?.invoiceNumber || ''} from Fixswift`;
    const body = `Please find your invoice attached.`;
    window.open(`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
  };

  const handleExportCsv = () => {
    alert('CSV export feature will be available soon!');
  };

  const handleExportImage = () => {
    alert('Image export feature will be available soon!');
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="secondary-button ml-2">
          <Share2 className="h-4 w-4 mr-2" />
          Export
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Export Invoice</DialogTitle>
          <DialogDescription>
            Choose how you want to export your invoice
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-1 gap-3 py-4">
          <button onClick={onDownloadPdf} className="export-action">
            <FileText className="export-icon" />
            <div className="flex flex-col items-start">
              <span className="font-medium">Download PDF</span>
              <span className="text-sm text-gray-500">Save invoice as PDF document</span>
            </div>
          </button>
          
          <button onClick={handleCopyLink} className="export-action">
            <Copy className="export-icon" />
            <div className="flex flex-col items-start">
              <span className="font-medium">Copy Link</span>
              <span className="text-sm text-gray-500">Copy shareable link to clipboard</span>
            </div>
          </button>
          
          <button onClick={handlePrint} className="export-action">
            <Printer className="export-icon" />
            <div className="flex flex-col items-start">
              <span className="font-medium">Print</span>
              <span className="text-sm text-gray-500">Print invoice directly</span>
            </div>
          </button>
          
          <button onClick={handleEmail} className="export-action">
            <Mail className="export-icon" />
            <div className="flex flex-col items-start">
              <span className="font-medium">Email</span>
              <span className="text-sm text-gray-500">Send invoice via email</span>
            </div>
          </button>
          
          <button onClick={handleExportCsv} className="export-action">
            <FileSpreadsheet className="export-icon" />
            <div className="flex flex-col items-start">
              <span className="font-medium">Export CSV</span>
              <span className="text-sm text-gray-500">Export data in CSV format</span>
            </div>
          </button>
          
          <button onClick={handleExportImage} className="export-action">
            <Image className="export-icon" />
            <div className="flex flex-col items-start">
              <span className="font-medium">Export Image</span>
              <span className="text-sm text-gray-500">Save invoice as image (PNG)</span>
            </div>
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}