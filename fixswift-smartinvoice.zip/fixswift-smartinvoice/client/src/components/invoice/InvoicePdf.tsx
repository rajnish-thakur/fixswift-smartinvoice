import React from 'react';
import { InvoiceData, InvoiceItem } from '@/lib/invoice-utils';
import { CURRENCIES } from '@/lib/currencies';
import { format } from 'date-fns';

// Helper function to convert number to words (for Indian Rupees)
function numberToWords(num: number): string {
  const single = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const double = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  const formatTens = (num: number): string => {
    if (num < 10) return single[num];
    if (num < 20) return double[num - 10];
    return tens[Math.floor(num / 10)] + (num % 10 !== 0 ? ' ' + single[num % 10] : '');
  };

  if (num === 0) return 'Zero';
  
  // Handle lakhs and crores (Indian number system)
  let words = '';
  if (num >= 10000000) { // Crore
    words += formatTens(Math.floor(num / 10000000)) + ' Crore ';
    num %= 10000000;
  }
  if (num >= 100000) { // Lakh
    words += formatTens(Math.floor(num / 100000)) + ' Lakh ';
    num %= 100000;
  }
  if (num >= 1000) { // Thousand
    words += formatTens(Math.floor(num / 1000)) + ' Thousand ';
    num %= 1000;
  }
  if (num >= 100) { // Hundred
    words += formatTens(Math.floor(num / 100)) + ' Hundred ';
    num %= 100;
  }
  if (num > 0) {
    words += formatTens(num);
  }
  
  return words.trim();
}

// Helper function to format currency
const formatCurrency = (amount: number, currencyCode: string): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: currencyCode,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
};

// Format date for invoice
const formatDate = (date: string | Date): string => {
  if (typeof date === 'string') {
    return format(new Date(date), 'dd MMM yyyy');
  }
  return format(date, 'dd MMM yyyy');
};

interface InvoicePdfProps {
  invoiceData: InvoiceData;
}

export const InvoicePdf: React.FC<InvoicePdfProps> = ({ invoiceData }) => {
  const currency = CURRENCIES.find(c => c.code === invoiceData.currency) || { code: 'INR', symbol: '₹', name: 'Indian Rupee' };
  
  // Calculate the subtotal
  const subtotal = invoiceData.subtotal || 0;
  
  // Calculate discount amount
  const discountAmount = subtotal * ((invoiceData.discountTotal || 0) / 100);
  
  // Calculate taxable amount
  const taxableAmount = subtotal - discountAmount;
  
  // Get GST details
  const isIntraState = invoiceData.gstType === 'cgst_sgst';
  const gstRate = invoiceData.gstRate || 0;
  const cgstRate = isIntraState ? gstRate / 2 : 0;
  const sgstRate = isIntraState ? gstRate / 2 : 0;
  const igstRate = !isIntraState ? gstRate : 0;
  
  // GST values
  const cgstValue = invoiceData.cgstValue || 0;
  const sgstValue = invoiceData.sgstValue || 0;
  const igstValue = invoiceData.igstValue || 0;
  
  // Calculate total
  const total = invoiceData.total || 0;
  
  // Get amount in words
  const amountInWords = `INR ${numberToWords(Math.round(total))} Rupees Only`;
  
  return (
    <div className="bg-white p-8 max-w-4xl mx-auto">
      {/* Header */}
      <div className="text-center mb-4">
        <h1 className="text-xl font-bold uppercase tracking-wider">TAX INVOICE</h1>
        <div className="text-right text-sm text-gray-600">ORIGINAL FOR RECIPIENT</div>
      </div>
      
      {/* Company/Seller Info */}
      <div className="text-center mb-6">
        <div className="flex justify-center items-center mb-2">
          {invoiceData.logo && (
            <img src={invoiceData.logo} alt="Company Logo" className="h-12 mr-2" />
          )}
          <h2 className="text-lg font-bold">{invoiceData.businessDetails?.split('\n')[0] || 'Your Business Name'}</h2>
        </div>
        
        {invoiceData.gstNumber && (
          <div className="text-sm font-semibold">GSTIN: {invoiceData.gstNumber}</div>
        )}
        
        <div className="text-sm whitespace-pre-line">
          {invoiceData.businessDetails?.split('\n').slice(1).join('\n')}
        </div>
      </div>
      
      {/* Buyer and Invoice Details */}
      <div className="grid grid-cols-2 gap-4 border-t border-b border-gray-300 py-4 mb-6">
        <div>
          <h3 className="font-bold text-sm mb-1">Customer Details:</h3>
          <div className="text-sm whitespace-pre-line">
            {invoiceData.clientDetails || 'No client details provided'}
          </div>
        </div>
        
        <div className="text-sm">
          <table className="w-full text-right">
            <tbody>
              <tr>
                <td className="font-bold pr-4">Invoice #:</td>
                <td>{invoiceData.invoiceNumber}</td>
              </tr>
              <tr>
                <td className="font-bold pr-4">Invoice Date:</td>
                <td>{formatDate(invoiceData.issueDate)}</td>
              </tr>
              <tr>
                <td className="font-bold pr-4">Due Date:</td>
                <td>{formatDate(invoiceData.dueDate)}</td>
              </tr>
              {isIntraState && (
                <tr>
                  <td className="font-bold pr-4">Place of Supply:</td>
                  <td>Same State (Intra-State)</td>
                </tr>
              )}
              {!isIntraState && (
                <tr>
                  <td className="font-bold pr-4">Place of Supply:</td>
                  <td>Inter-State</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Invoice Items */}
      <table className="w-full mb-6 text-sm">
        <thead>
          <tr className="border-b border-gray-300">
            <th className="py-2 text-left w-8">#</th>
            <th className="py-2 text-left">Item</th>
            <th className="py-2 text-center">HSN/SAC</th>
            <th className="py-2 text-center">Tax</th>
            <th className="py-2 text-center">Qty</th>
            <th className="py-2 text-right">Rate / Item</th>
            <th className="py-2 text-right">Amount</th>
          </tr>
        </thead>
        <tbody>
          {invoiceData.items && invoiceData.items.map((item, index) => (
            <tr key={item.id} className="border-b border-gray-200">
              <td className="py-2 text-left">{index + 1}</td>
              <td className="py-2 text-left">{item.description || 'No description'}</td>
              <td className="py-2 text-center">-</td>
              <td className="py-2 text-center">{gstRate}%</td>
              <td className="py-2 text-center">{item.quantity} PCS</td>
              <td className="py-2 text-right">{formatCurrency(item.rate, currency.code)}</td>
              <td className="py-2 text-right">{formatCurrency(item.amount, currency.code)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      
      {/* Tax Summary */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div></div> {/* Empty column for alignment */}
        <div>
          <table className="w-full text-sm">
            <tbody>
              <tr className="border-t border-gray-200">
                <td className="py-1 text-right font-semibold">Taxable Amount</td>
                <td className="py-1 text-right w-1/3">{formatCurrency(taxableAmount, currency.code)}</td>
              </tr>
              
              {isIntraState && (
                <>
                  <tr>
                    <td className="py-1 text-right">CGST {cgstRate}% @ {formatCurrency(taxableAmount, currency.code)}</td>
                    <td className="py-1 text-right">{formatCurrency(cgstValue, currency.code)}</td>
                  </tr>
                  <tr>
                    <td className="py-1 text-right">SGST {sgstRate}% @ {formatCurrency(taxableAmount, currency.code)}</td>
                    <td className="py-1 text-right">{formatCurrency(sgstValue, currency.code)}</td>
                  </tr>
                </>
              )}
              
              {!isIntraState && (
                <tr>
                  <td className="py-1 text-right">IGST {igstRate}% @ {formatCurrency(taxableAmount, currency.code)}</td>
                  <td className="py-1 text-right">{formatCurrency(igstValue, currency.code)}</td>
                </tr>
              )}
              
              {invoiceData.shipping && invoiceData.shipping > 0 && (
                <tr>
                  <td className="py-1 text-right">Shipping</td>
                  <td className="py-1 text-right">{formatCurrency(invoiceData.shipping, currency.code)}</td>
                </tr>
              )}
              
              <tr className="border-t border-gray-300 font-bold">
                <td className="py-2 text-right">Total</td>
                <td className="py-2 text-right">{formatCurrency(total, currency.code)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Amount in Words */}
      <div className="text-sm mb-6">
        <p className="font-semibold">Amount Chargeable (in words): {amountInWords}. E & O.E</p>
      </div>
      
      {/* GST Summary Table */}
      <div className="mb-6">
        <table className="w-full text-sm border border-gray-300">
          <thead>
            <tr className="bg-gray-100">
              <th className="border border-gray-300 p-2 text-left">HSN/SAC</th>
              <th className="border border-gray-300 p-2 text-center">Taxable Value</th>
              {isIntraState ? (
                <>
                  <th className="border border-gray-300 p-2 text-center" colSpan={2}>Central Tax</th>
                  <th className="border border-gray-300 p-2 text-center" colSpan={2}>State/UT Tax</th>
                </>
              ) : (
                <th className="border border-gray-300 p-2 text-center" colSpan={2}>Integrated Tax</th>
              )}
              <th className="border border-gray-300 p-2 text-center">Total Tax Amount</th>
            </tr>
            
            {isIntraState && (
              <tr className="bg-gray-100">
                <th className="border border-gray-300 p-2 text-left"></th>
                <th className="border border-gray-300 p-2 text-center"></th>
                <th className="border border-gray-300 p-2 text-center">Rate</th>
                <th className="border border-gray-300 p-2 text-center">Amount</th>
                <th className="border border-gray-300 p-2 text-center">Rate</th>
                <th className="border border-gray-300 p-2 text-center">Amount</th>
                <th className="border border-gray-300 p-2 text-center"></th>
              </tr>
            )}
            
            {!isIntraState && (
              <tr className="bg-gray-100">
                <th className="border border-gray-300 p-2 text-left"></th>
                <th className="border border-gray-300 p-2 text-center"></th>
                <th className="border border-gray-300 p-2 text-center">Rate</th>
                <th className="border border-gray-300 p-2 text-center">Amount</th>
                <th className="border border-gray-300 p-2 text-center"></th>
              </tr>
            )}
          </thead>
          <tbody>
            <tr>
              <td className="border border-gray-300 p-2 text-left">-</td>
              <td className="border border-gray-300 p-2 text-right">{formatCurrency(taxableAmount, currency.code)}</td>
              
              {isIntraState ? (
                <>
                  <td className="border border-gray-300 p-2 text-center">{cgstRate}%</td>
                  <td className="border border-gray-300 p-2 text-right">{formatCurrency(cgstValue, currency.code)}</td>
                  <td className="border border-gray-300 p-2 text-center">{sgstRate}%</td>
                  <td className="border border-gray-300 p-2 text-right">{formatCurrency(sgstValue, currency.code)}</td>
                  <td className="border border-gray-300 p-2 text-right">{formatCurrency(cgstValue + sgstValue, currency.code)}</td>
                </>
              ) : (
                <>
                  <td className="border border-gray-300 p-2 text-center">{igstRate}%</td>
                  <td className="border border-gray-300 p-2 text-right">{formatCurrency(igstValue, currency.code)}</td>
                  <td className="border border-gray-300 p-2 text-right">{formatCurrency(igstValue, currency.code)}</td>
                </>
              )}
            </tr>
            
            <tr className="font-semibold">
              <td className="border border-gray-300 p-2 text-center">TOTAL</td>
              <td className="border border-gray-300 p-2 text-right">{formatCurrency(taxableAmount, currency.code)}</td>
              
              {isIntraState ? (
                <>
                  <td className="border border-gray-300 p-2 text-center"></td>
                  <td className="border border-gray-300 p-2 text-right">{formatCurrency(cgstValue, currency.code)}</td>
                  <td className="border border-gray-300 p-2 text-center"></td>
                  <td className="border border-gray-300 p-2 text-right">{formatCurrency(sgstValue, currency.code)}</td>
                  <td className="border border-gray-300 p-2 text-right">{formatCurrency(cgstValue + sgstValue, currency.code)}</td>
                </>
              ) : (
                <>
                  <td className="border border-gray-300 p-2 text-center"></td>
                  <td className="border border-gray-300 p-2 text-right">{formatCurrency(igstValue, currency.code)}</td>
                  <td className="border border-gray-300 p-2 text-right">{formatCurrency(igstValue, currency.code)}</td>
                </>
              )}
            </tr>
          </tbody>
        </table>
        
        <div className="text-right text-sm font-bold mt-2">
          Amount Payable: {formatCurrency(total, currency.code)}
        </div>
      </div>
      
      {/* Payment Info and Signature */}
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <h3 className="font-bold mb-2">Bank Details:</h3>
          {invoiceData.paymentMethod === 'bank_transfer' ? (
            <div className="whitespace-pre-line">{invoiceData.paymentMethod || ''}</div>
          ) : (
            <p>Please contact for bank details.</p>
          )}
          
          <div className="mt-4">
            <h3 className="font-bold mb-2">Pay using UPI:</h3>
            <p>Scan the QR code or use UPI ID</p>
          </div>
          
          <div className="mt-4">
            <h3 className="font-bold mb-2">Notes:</h3>
            <p>Thank You!</p>
            <p>We appreciate your business.</p>
          </div>
        </div>
        
        <div className="text-right">
          <div className="h-20"></div> {/* Space for signature */}
          
          <div className="mt-6 mb-2 font-bold">
            For {invoiceData.businessDetails?.split('\n')[0] || 'Your Business Name'}
          </div>
          
          <div className="mt-12">
            Authorized Signatory
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <div className="mt-8 text-center text-xs text-gray-600 border-t border-gray-300 pt-4">
        <p>
          This is a computer-generated invoice and does not require a signature.
        </p>
      </div>
    </div>
  );
};