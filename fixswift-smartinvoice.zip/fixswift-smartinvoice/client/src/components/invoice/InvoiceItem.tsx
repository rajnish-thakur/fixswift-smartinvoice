import React, { useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Trash2 } from 'lucide-react';
import { useFormContext, useWatch } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { CURRENCIES } from '@/lib/currencies';

interface InvoiceItemProps {
  index: number;
  currency: string;
  onRemove: () => void;
}

export function InvoiceItem({ index, currency, onRemove }: InvoiceItemProps) {
  const { register, setValue, control } = useFormContext();
  
  // Watch values for real-time calculation
  const quantity = useWatch({
    control,
    name: `items.${index}.quantity`,
    defaultValue: 1,
  });
  
  const rate = useWatch({
    control,
    name: `items.${index}.rate`,
    defaultValue: 0,
  });
  
  const discount = useWatch({
    control,
    name: `items.${index}.discount`,
    defaultValue: 0,
  });

  // Calculate amount when any value changes
  useEffect(() => {
    const calculatedAmount = (Number(quantity) * Number(rate)) * (1 - Number(discount) / 100);
    setValue(`items.${index}.amount`, calculatedAmount);
  }, [quantity, rate, discount, setValue, index]);

  // Get currency symbol
  const currencySymbol = CURRENCIES.find(c => c.code === currency)?.symbol || '$';

  // Handle input focus to clear default value
  const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    if (e.target.value === '0') {
      e.target.value = '';
    }
  };

  // Handle input blur to reset empty value to 0
  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    if (e.target.value === '') {
      e.target.value = '0';
    }
  };

  return (
    <div className="grid grid-cols-12 gap-3 items-start mb-3 p-3 rounded-lg border border-gray-100 bg-white hover:border-gray-200 transition-colors">
      {/* Description */}
      <div className="col-span-12 md:col-span-5">
        <Textarea 
          className="min-h-[42px] py-2 resize-y focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
          placeholder="Item description"
          {...register(`items.${index}.description`)}
        />
      </div>
      
      {/* Quantity */}
      <div className="col-span-3 md:col-span-2">
        <Input
          type="number"
          min="0"
          className="w-full text-center focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
          {...register(`items.${index}.quantity`, { 
            valueAsNumber: true,
            onChange: (e) => {
              if (e.target.value === '') {
                e.target.value = '0';
              }
            }
          })}
          onBlur={handleBlur}
          onFocus={handleFocus}
        />
        <div className="text-xs text-center text-gray-500 mt-1">Quantity</div>
      </div>
      
      {/* Rate */}
      <div className="col-span-3 md:col-span-2">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-500">
            {currencySymbol}
          </div>
          <Input
            type="number"
            min="0"
            step="0.01"
            className="w-full pl-7 text-center focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
            {...register(`items.${index}.rate`, { 
              valueAsNumber: true,
              onChange: (e) => {
                if (e.target.value === '') {
                  e.target.value = '0';
                }
              }
            })}
            onBlur={handleBlur}
            onFocus={handleFocus}
          />
        </div>
        <div className="text-xs text-center text-gray-500 mt-1">Rate</div>
      </div>
      
      {/* Discount */}
      <div className="col-span-3 md:col-span-1">
        <div className="relative">
          <Input
            type="number"
            min="0"
            max="100"
            className="w-full pr-7 text-center focus:border-blue-400 focus:ring-1 focus:ring-blue-200"
            {...register(`items.${index}.discount`, { 
              valueAsNumber: true,
              onChange: (e) => {
                if (e.target.value === '') {
                  e.target.value = '0';
                }
              }
            })}
            onFocus={handleFocus}
            onBlur={handleBlur}
          />
          <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-gray-500">
            %
          </div>
        </div>
        <div className="text-xs text-center text-gray-500 mt-1">Discount</div>
      </div>
      
      {/* Amount */}
      <div className="col-span-2 md:col-span-1 relative">
        <div className="h-[42px] flex items-center justify-center rounded-md border border-transparent bg-gray-100 px-3 font-medium text-gray-800">
          {currencySymbol}
          {(Number(quantity) * Number(rate) * (1 - Number(discount) / 100)).toFixed(2)}
        </div>
        <div className="text-xs text-center text-gray-500 mt-1">Amount</div>
      </div>
      
      {/* Delete button */}
      <div className="col-span-1 flex justify-end">
        <Button 
          type="button" 
          variant="ghost" 
          size="icon"
          onClick={onRemove}
          className="h-10 w-10 text-gray-400 hover:text-red-500"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}