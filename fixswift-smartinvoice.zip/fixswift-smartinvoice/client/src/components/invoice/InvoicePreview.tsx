import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { FileText, X } from "lucide-react";
import { useInvoiceStore } from "@/lib/invoice-utils";
import { toast } from "@/hooks/use-toast";
import { CURRENCIES } from "@/lib/currencies";
import { format } from "date-fns";
import { ExportActions } from "@/components/invoice/ExportActions";

interface InvoicePreviewProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function InvoicePreview({ open, onOpenChange }: InvoicePreviewProps) {
  const { invoiceData } = useInvoiceStore();

  const getPaymentTermsText = (code: string) => {
    switch (code) {
      case "net7": return "NET 7";
      case "net15": return "NET 15";
      case "net30": return "NET 30";
      case "net45": return "NET 45";
      case "net60": return "NET 60";
      case "due_on_receipt": return "Due on receipt";
      default: return code;
    }
  };

  const getCurrencySymbol = (code: string) => {
    const currency = CURRENCIES.find(c => c.code === code);
    return currency ? currency.symbol : code;
  };

  const handleGeneratePDF = async () => {
    try {
      if (!invoiceData) {
        throw new Error("No invoice data available");
      }
      
      // Save the invoice to the database first
      const response = await fetch('/api/invoices', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(invoiceData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to save invoice');
      }
      
      const savedInvoice = await response.json();
      
      // Download the PDF
      window.open(`/api/invoices/${savedInvoice.id}/download`, '_blank');
      
      toast({
        title: "Success",
        description: "Invoice PDF generated successfully!",
      });
      onOpenChange(false);
    } catch (error) {
      console.error("Error generating PDF:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "There was a problem generating the PDF. Please try again.",
      });
    }
  };

  if (!invoiceData) {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl w-full max-h-[80vh] p-0">
        <DialogHeader className="p-6 border-b border-gray-200 flex justify-between items-center">
          <div>
            <DialogTitle className="text-xl font-semibold text-gray-800">Invoice Preview</DialogTitle>
            <DialogDescription>Review your invoice before generating the PDF</DialogDescription>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => onOpenChange(false)}
            className="absolute right-4 top-4"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>
        
        <ScrollArea className="p-6 max-h-[calc(80vh-160px)]">
          <div className="space-y-6">
            <div className="flex justify-between items-start">
              <div>
                {invoiceData.logo ? (
                  <img src={invoiceData.logo} alt="Company logo" className="h-16 mb-4" />
                ) : (
                  <div className="h-16 w-40 bg-gray-200 rounded mb-4 flex items-center justify-center text-gray-500">
                    No Logo
                  </div>
                )}
                <h2 className="text-2xl font-bold text-gray-800">INVOICE</h2>
                <p className="text-gray-600">#{invoiceData.invoiceNumber}</p>
              </div>
              <div className="text-right">
                <p className="font-medium">Issue Date: {typeof invoiceData.issueDate === 'string' ? invoiceData.issueDate : format(new Date(invoiceData.issueDate), 'MMM dd, yyyy')}</p>
                <p className="font-medium">Due Date: {typeof invoiceData.dueDate === 'string' ? invoiceData.dueDate : format(new Date(invoiceData.dueDate), 'MMM dd, yyyy')}</p>
                <p className="text-gray-600">Payment Terms: {getPaymentTermsText(invoiceData.paymentTerms)}</p>
                <p className="text-gray-600">Currency: {invoiceData.currency} {getCurrencySymbol(invoiceData.currency)}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-gray-200 pt-6">
              {/* From */}
              <div>
                <h3 className="text-lg font-medium text-gray-700 mb-2">From</h3>
                <div className="whitespace-pre-line text-gray-600">
                  {invoiceData.businessDetails || "No business details provided"}
                </div>
                {invoiceData.gstNumber && (
                  <div className="mt-2">
                    <span className="font-medium text-gray-700">GSTIN: </span>
                    <span className="text-gray-600">{invoiceData.gstNumber}</span>
                  </div>
                )}
              </div>
              
              {/* To */}
              <div>
                <h3 className="text-lg font-medium text-gray-700 mb-2">Bill To</h3>
                <div className="whitespace-pre-line text-gray-600">
                  {invoiceData.clientDetails || "No client details provided"}
                </div>
              </div>
            </div>
            
            {/* Invoice Items */}
            <div className="border-t border-gray-200 pt-6 mt-6">
              <h3 className="text-lg font-medium text-gray-700 mb-4">Items</h3>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-300">
                      <th className="text-left py-2 font-medium text-gray-700">Item Description</th>
                      <th className="text-center py-2 font-medium text-gray-700">Qty</th>
                      <th className="text-center py-2 font-medium text-gray-700">Rate</th>
                      <th className="text-center py-2 font-medium text-gray-700">Discount</th>
                      <th className="text-right py-2 font-medium text-gray-700">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoiceData.items && invoiceData.items.map((item) => (
                      <tr key={item.id} className="border-b border-gray-200">
                        <td className="py-3 text-gray-700">{item.description || "No description"}</td>
                        <td className="py-3 text-center text-gray-700">{item.quantity}</td>
                        <td className="py-3 text-center text-gray-700">
                          {getCurrencySymbol(invoiceData.currency)}{item.rate.toFixed(2)}
                        </td>
                        <td className="py-3 text-center text-gray-700">{item.discount}%</td>
                        <td className="py-3 text-right text-gray-700">
                          {getCurrencySymbol(invoiceData.currency)}{item.amount.toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              {/* Invoice Totals */}
              <div className="mt-6 md:w-1/2 ml-auto">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-right font-medium text-gray-700">Subtotal:</div>
                  <div className="text-right">
                    {getCurrencySymbol(invoiceData.currency)}
                    {(invoiceData.subtotal || 0).toFixed(2)}
                  </div>
                  
                  <div className="text-right font-medium text-gray-700">
                    Discount ({invoiceData.discountTotal || 0}%):
                  </div>
                  <div className="text-right">
                    {getCurrencySymbol(invoiceData.currency)}
                    {((invoiceData.subtotal || 0) * (invoiceData.discountTotal || 0) / 100).toFixed(2)}
                  </div>
                  
                  {/* GST information based on type */}
                  {invoiceData.gstType === "cgst_sgst" ? (
                    <>
                      {/* Display CGST */}
                      <div className="text-right font-medium text-gray-700">
                        CGST ({(invoiceData.gstRate || 0) / 2}%):
                      </div>
                      <div className="text-right">
                        {getCurrencySymbol(invoiceData.currency)}
                        {(invoiceData.cgstValue || 0).toFixed(2)}
                      </div>
                      
                      {/* Display SGST */}
                      <div className="text-right font-medium text-gray-700">
                        SGST ({(invoiceData.gstRate || 0) / 2}%):
                      </div>
                      <div className="text-right">
                        {getCurrencySymbol(invoiceData.currency)}
                        {(invoiceData.sgstValue || 0).toFixed(2)}
                      </div>
                    </>
                  ) : (
                    <>
                      {/* Display IGST */}
                      <div className="text-right font-medium text-gray-700">
                        IGST ({invoiceData.gstRate || 0}%):
                      </div>
                      <div className="text-right">
                        {getCurrencySymbol(invoiceData.currency)}
                        {(invoiceData.igstValue || 0).toFixed(2)}
                      </div>
                    </>
                  )}
                  
                  <div className="text-right font-medium text-gray-700">Shipping:</div>
                  <div className="text-right">
                    {getCurrencySymbol(invoiceData.currency)}
                    {(invoiceData.shipping || 0).toFixed(2)}
                  </div>
                  
                  <div className="text-right font-medium text-gray-700 text-lg">Total:</div>
                  <div className="text-right font-bold text-lg text-blue-600">
                    {getCurrencySymbol(invoiceData.currency)}
                    {(invoiceData.total || 0).toFixed(2)}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Payment Method */}
            {invoiceData.paymentMethod && (
              <div className="border-t border-gray-200 pt-6 mt-6">
                <h3 className="text-lg font-medium text-gray-700 mb-3">Payment Method</h3>
                <div className="p-4 bg-gray-50 rounded-lg text-gray-700 whitespace-pre-line">
                  {invoiceData.paymentMethod}
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
        
        <DialogFooter className="p-6 border-t border-gray-200 bg-gray-50">
          <div className="flex space-x-2">
            <Button 
              onClick={handleGeneratePDF} 
              className="primary-button flex items-center"
            >
              <FileText className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
            <ExportActions invoiceData={invoiceData} onDownloadPdf={handleGeneratePDF} />
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
