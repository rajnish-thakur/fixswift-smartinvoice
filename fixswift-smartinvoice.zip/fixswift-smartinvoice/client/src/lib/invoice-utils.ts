import { create } from 'zustand';

export interface InvoiceItem {
  id: string;
  description?: string;
  quantity: number;
  rate: number;
  discount: number;
  amount: number;
}

export interface InvoiceData {
  invoiceNumber: string;
  paymentTerms: string;
  issueDate: string | Date;
  dueDate: string | Date;
  currency: string;
  logo?: string | null;
  businessDetails?: string;
  clientDetails?: string;
  items?: InvoiceItem[];
  subtotal?: number;
  discountTotal?: number;
  // Indian GST support
  gstType?: "cgst_sgst" | "igst";
  gstNumber?: string;
  gstRate?: number;
  cgstValue?: number;
  sgstValue?: number;
  igstValue?: number;
  shipping?: number;
  total?: number;
  paymentMethod?: string;
}

interface InvoiceStore {
  invoiceData: InvoiceData | null;
  setInvoiceData: (data: InvoiceData) => void;
  clearInvoiceData: () => void;
}

export const useInvoiceStore = create<InvoiceStore>((set) => ({
  invoiceData: null,
  setInvoiceData: (data) => set({ invoiceData: data }),
  clearInvoiceData: () => set({ invoiceData: null }),
}));

// Helper function to format currency
export const formatCurrency = (amount: number, currencyCode: string): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currencyCode,
  }).format(amount);
};

// Helper function to get payment terms text
export const getPaymentTermsText = (code: string): string => {
  switch (code) {
    case 'net7': return 'NET 7 (7 days)';
    case 'net15': return 'NET 15 (15 days)';
    case 'net30': return 'NET 30 (30 days)';
    case 'net45': return 'NET 45 (45 days)';
    case 'net60': return 'NET 60 (60 days)';
    case 'due_on_receipt': return 'Due on receipt';
    default: return code;
  }
};
