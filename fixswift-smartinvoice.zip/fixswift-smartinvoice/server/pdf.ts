import PDFDocument from 'pdfkit';
import { InsertInvoice } from '@shared/schema';
import { format } from 'date-fns';
import fs from 'fs';
import path from 'path';
import { Readable } from 'stream';

// Helper function to convert number to words (for Indian Rupees)
function numberToWords(num: number): string {
  const single = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const double = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  const formatTens = (num: number): string => {
    if (num < 10) return single[num];
    if (num < 20) return double[num - 10];
    return tens[Math.floor(num / 10)] + (num % 10 !== 0 ? ' ' + single[num % 10] : '');
  };

  if (num === 0) return 'Zero';
  
  // Handle lakhs and crores (Indian number system)
  let words = '';
  if (num >= 10000000) { // Crore
    words += formatTens(Math.floor(num / 10000000)) + ' Crore ';
    num %= 10000000;
  }
  if (num >= 100000) { // Lakh
    words += formatTens(Math.floor(num / 100000)) + ' Lakh ';
    num %= 100000;
  }
  if (num >= 1000) { // Thousand
    words += formatTens(Math.floor(num / 1000)) + ' Thousand ';
    num %= 1000;
  }
  if (num >= 100) { // Hundred
    words += formatTens(Math.floor(num / 100)) + ' Hundred ';
    num %= 100;
  }
  if (num > 0) {
    words += formatTens(num);
  }
  
  return words.trim();
}

// Helper function to format currency
const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount).replace('₹', '');
};

// Format date for invoice
const formatDate = (date: string | Date): string => {
  if (typeof date === 'string') {
    return format(new Date(date), 'dd MMM yyyy');
  }
  return format(date, 'dd MMM yyyy');
};

// Generate invoice HTML
export const generateInvoiceHtml = (invoiceData: any): string => {
  // Calculate the subtotal
  const subtotal = invoiceData.subtotal || 0;
  
  // Calculate discount amount
  const discountAmount = subtotal * ((invoiceData.discountTotal || 0) / 100);
  
  // Calculate taxable amount
  const taxableAmount = subtotal - discountAmount;
  
  // Get GST details
  const isIntraState = invoiceData.gstType === 'cgst_sgst';
  const gstRate = invoiceData.gstRate || 0;
  const cgstRate = isIntraState ? gstRate / 2 : 0;
  const sgstRate = isIntraState ? gstRate / 2 : 0;
  const igstRate = !isIntraState ? gstRate : 0;
  
  // GST values
  const cgstValue = invoiceData.cgstValue || 0;
  const sgstValue = invoiceData.sgstValue || 0;
  const igstValue = invoiceData.igstValue || 0;
  
  // Calculate total
  const total = invoiceData.total || 0;
  
  // Get amount in words
  const amountInWords = `INR ${numberToWords(Math.round(total))} Rupees Only`;
  
  // Generate items HTML
  const itemsHtml = invoiceData.items?.map((item: any, index: number) => `
    <tr style="border-bottom: 1px solid #ddd;">
      <td style="padding: 8px 4px; text-align: left;">${index + 1}</td>
      <td style="padding: 8px 4px; text-align: left;">${item.description || 'No description'}</td>
      <td style="padding: 8px 4px; text-align: center;">-</td>
      <td style="padding: 8px 4px; text-align: center;">${gstRate}%</td>
      <td style="padding: 8px 4px; text-align: center;">${item.quantity} PCS</td>
      <td style="padding: 8px 4px; text-align: right;">₹${formatCurrency(item.rate)}</td>
      <td style="padding: 8px 4px; text-align: right;">₹${formatCurrency(item.amount)}</td>
    </tr>
  `).join('') || '';
  
  // Generate GST breakdown table
  let gstTableHtml = '';
  if (isIntraState) {
    gstTableHtml = `
      <tr>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">HSN/SAC</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Taxable Value</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;" colspan="2">Central Tax</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;" colspan="2">State/UT Tax</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Total Tax Amount</th>
      </tr>
      <tr>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;"></th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;"></th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Rate</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Amount</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Rate</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Amount</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;"></th>
      </tr>
      <tr>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: left;">-</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(taxableAmount)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">${cgstRate}%</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(cgstValue)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">${sgstRate}%</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(sgstValue)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(cgstValue + sgstValue)}</td>
      </tr>
      <tr style="font-weight: bold;">
        <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">TOTAL</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(taxableAmount)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: center;"></td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(cgstValue)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: center;"></td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(sgstValue)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(cgstValue + sgstValue)}</td>
      </tr>
    `;
  } else {
    gstTableHtml = `
      <tr>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">HSN/SAC</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Taxable Value</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;" colspan="2">Integrated Tax</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Total Tax Amount</th>
      </tr>
      <tr>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;"></th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;"></th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Rate</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;">Amount</th>
        <th style="border: 1px solid #ddd; padding: 8px; text-align: center;"></th>
      </tr>
      <tr>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: left;">-</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(taxableAmount)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">${igstRate}%</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(igstValue)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(igstValue)}</td>
      </tr>
      <tr style="font-weight: bold;">
        <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">TOTAL</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(taxableAmount)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: center;"></td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(igstValue)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${formatCurrency(igstValue)}</td>
      </tr>
    `;
  }

  // Construct HTML
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Invoice ${invoiceData.invoiceNumber}</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          font-size: 12px;
          line-height: 1.5;
          color: #333;
          margin: 0;
          padding: 20px;
        }
        .header {
          text-align: center;
          margin-bottom: 20px;
        }
        h1 {
          font-size: 18px;
          text-transform: uppercase;
          letter-spacing: 2px;
          margin: 0;
        }
        .original-text {
          text-align: right;
          font-size: 10px;
          color: #666;
        }
        .company-info {
          text-align: center;
          margin-bottom: 20px;
        }
        .invoice-details {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 20px;
          border-top: 1px solid #ddd;
          border-bottom: 1px solid #ddd;
          padding: 15px 0;
          margin-bottom: 20px;
        }
        .client-details h3, .invoice-meta h3 {
          font-size: 12px;
          margin: 0 0 5px 0;
        }
        .invoice-meta table {
          width: 100%;
          text-align: right;
        }
        .invoice-meta table td:first-child {
          font-weight: bold;
          padding-right: 10px;
        }
        .items-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 20px;
        }
        .items-table th {
          background-color: #f5f5f5;
          padding: 8px 4px;
          border-bottom: 1px solid #ddd;
          text-align: left;
        }
        .totals {
          width: 50%;
          margin-left: auto;
        }
        .totals table {
          width: 100%;
        }
        .totals td {
          padding: 4px 0;
        }
        .totals td:first-child {
          text-align: right;
          padding-right: 10px;
        }
        .totals td:last-child {
          text-align: right;
        }
        .total-row {
          font-weight: bold;
          border-top: 1px solid #ddd;
        }
        .amount-words {
          margin-bottom: 20px;
          font-weight: 600;
        }
        .gst-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 20px;
        }
        .gst-table th, .gst-table td {
          background-color: #f9f9f9;
        }
        .payment-signature {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 20px;
          margin-top: 30px;
        }
        .signature-box {
          text-align: right;
        }
        .signature-line {
          margin-top: 50px;
        }
        .footer {
          margin-top: 40px;
          text-align: center;
          font-size: 10px;
          color: #666;
          border-top: 1px solid #ddd;
          padding-top: 10px;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>TAX INVOICE</h1>
        <div class="original-text">ORIGINAL FOR RECIPIENT</div>
      </div>
      
      <div class="company-info">
        <h2>${invoiceData.businessDetails?.split('\n')[0] || 'Your Business Name'}</h2>
        ${invoiceData.gstNumber ? `<div><strong>GSTIN: ${invoiceData.gstNumber}</strong></div>` : ''}
        <div>${invoiceData.businessDetails?.split('\n').slice(1).join('<br>') || ''}</div>
      </div>
      
      <div class="invoice-details">
        <div class="client-details">
          <h3>Customer Details:</h3>
          <div>${invoiceData.clientDetails?.replace(/\n/g, '<br>') || 'No client details provided'}</div>
        </div>
        
        <div class="invoice-meta">
          <table>
            <tr>
              <td>Invoice #:</td>
              <td>${invoiceData.invoiceNumber}</td>
            </tr>
            <tr>
              <td>Invoice Date:</td>
              <td>${formatDate(invoiceData.issueDate)}</td>
            </tr>
            <tr>
              <td>Due Date:</td>
              <td>${formatDate(invoiceData.dueDate)}</td>
            </tr>
            <tr>
              <td>Place of Supply:</td>
              <td>${isIntraState ? 'Same State (Intra-State)' : 'Inter-State'}</td>
            </tr>
          </table>
        </div>
      </div>
      
      <table class="items-table">
        <thead>
          <tr>
            <th style="width: 5%;">#</th>
            <th style="width: 35%;">Item</th>
            <th style="width: 10%; text-align: center;">HSN/SAC</th>
            <th style="width: 10%; text-align: center;">Tax</th>
            <th style="width: 10%; text-align: center;">Qty</th>
            <th style="width: 15%; text-align: right;">Rate / Item</th>
            <th style="width: 15%; text-align: right;">Amount</th>
          </tr>
        </thead>
        <tbody>
          ${itemsHtml}
        </tbody>
      </table>
      
      <div class="totals">
        <table>
          <tr>
            <td>Taxable Amount</td>
            <td>₹${formatCurrency(taxableAmount)}</td>
          </tr>
          
          ${isIntraState ? `
          <tr>
            <td>CGST ${cgstRate}% @ ₹${formatCurrency(taxableAmount)}</td>
            <td>₹${formatCurrency(cgstValue)}</td>
          </tr>
          <tr>
            <td>SGST ${sgstRate}% @ ₹${formatCurrency(taxableAmount)}</td>
            <td>₹${formatCurrency(sgstValue)}</td>
          </tr>
          ` : `
          <tr>
            <td>IGST ${igstRate}% @ ₹${formatCurrency(taxableAmount)}</td>
            <td>₹${formatCurrency(igstValue)}</td>
          </tr>
          `}
          
          ${invoiceData.shipping && invoiceData.shipping > 0 ? `
          <tr>
            <td>Shipping</td>
            <td>₹${formatCurrency(invoiceData.shipping)}</td>
          </tr>
          ` : ''}
          
          <tr class="total-row">
            <td>Total</td>
            <td>₹${formatCurrency(total)}</td>
          </tr>
        </table>
      </div>
      
      <div class="amount-words">
        Amount Chargeable (in words): ${amountInWords}. E & O.E
      </div>
      
      <table class="gst-table">
        <thead>
          ${gstTableHtml}
        </thead>
      </table>
      
      <div style="text-align: right; font-weight: bold; margin-top: 10px; margin-bottom: 20px;">
        Amount Payable: ₹${formatCurrency(total)}
      </div>
      
      <div class="payment-signature">
        <div class="payment-info">
          <h3>Bank Details:</h3>
          ${invoiceData.paymentMethod === 'bank_transfer' ? 
            `<div>${invoiceData.paymentMethod?.replace(/\n/g, '<br>') || ''}</div>` : 
            '<p>Please contact for bank details.</p>'}
          
          <div style="margin-top: 20px;">
            <h3>Pay using UPI:</h3>
            <p>Scan the QR code or use UPI ID</p>
          </div>
          
          <div style="margin-top: 20px;">
            <h3>Notes:</h3>
            <p>Thank You!</p>
            <p>We appreciate your business.</p>
          </div>
        </div>
        
        <div class="signature-box">
          <div style="margin-top: 30px;">
            <div style="font-weight: bold;">For ${invoiceData.businessDetails?.split('\n')[0] || 'Your Business Name'}</div>
          </div>
          
          <div class="signature-line">
            Authorized Signatory
          </div>
        </div>
      </div>
      
      <div class="footer">
        This is a computer-generated invoice and does not require a signature.
      </div>
    </body>
    </html>
  `;
};

// Generate a simple PDF from invoice data using PDFKit
export async function generateInvoicePdf(invoiceData: any): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      // Create a simple PDF document with minimal content
      const doc = new PDFDocument({
        size: 'A4',
        margin: 50
      });
      
      // Capture PDF data to buffer
      const buffers: Buffer[] = [];
      doc.on('data', (chunk) => {
        buffers.push(chunk);
      });
      
      doc.on('end', () => {
        const pdfData = Buffer.concat(buffers);
        resolve(pdfData);
      });
      
      // Add simple content
      doc.fontSize(20).text('Invoice GST PDF', {
        align: 'center'
      });
      
      doc.moveDown();
      doc.fontSize(12).text(`Invoice Number: ${invoiceData.invoiceNumber || 'N/A'}`);
      
      // Simple table
      doc.moveDown(2);
      doc.fontSize(14).text('Summary', { underline: true });
      doc.moveDown();
      
      const tableData = [
        ['Item', 'Amount'],
        ['Subtotal', `₹ ${invoiceData.subtotal || 0}`],
        ['GST', `₹ ${invoiceData.gstValue || 0}`],
        ['Total', `₹ ${invoiceData.total || 0}`]
      ];
      
      let y = doc.y;
      tableData.forEach((row, i) => {
        doc.fontSize(i === 0 ? 12 : 10)
           .text(row[0], 100, y, { width: 200 })
           .text(row[1], 300, y, { width: 100 });
        y += 20;
      });
      
      // Finalize PDF file
      doc.end();
      
      // Calculate values
      const subtotal = invoiceData.subtotal || 0;
      const discountAmount = subtotal * ((invoiceData.discountTotal || 0) / 100);
      const taxableAmount = subtotal - discountAmount;
      const isIntraState = invoiceData.gstType === 'cgst_sgst';
      const gstRate = invoiceData.gstRate || 0;
      const cgstRate = isIntraState ? gstRate / 2 : 0;
      const sgstRate = isIntraState ? gstRate / 2 : 0;
      const igstRate = !isIntraState ? gstRate : 0;
      const cgstValue = invoiceData.cgstValue || 0;
      const sgstValue = invoiceData.sgstValue || 0;
      const igstValue = invoiceData.igstValue || 0;
      const total = invoiceData.total || 0;
      const amountInWords = `INR ${numberToWords(Math.round(total))} Rupees Only`;
      
      // Define commonly used positions and measures
      const pageWidth = doc.page.width - 100;
      const centerPos = doc.page.width / 2;
      
      // Header
      doc.fontSize(16).font('Helvetica-Bold').text('TAX INVOICE', centerPos, 50, { align: 'center' });
      doc.fontSize(8).font('Helvetica').text('ORIGINAL FOR RECIPIENT', { align: 'right' });
      doc.moveDown(1);
      
      // Company info
      const businessName = invoiceData.businessDetails?.split('\n')[0] || 'Your Business Name';
      doc.fontSize(14).font('Helvetica-Bold').text(businessName, { align: 'center' });
      
      if (invoiceData.businessDetails) {
        const businessLines = invoiceData.businessDetails.split('\n');
        if (businessLines.length > 1) {
          doc.fontSize(10).font('Helvetica').text(businessLines.slice(1).join('\n'), { align: 'center' });
        }
      }
      
      if (invoiceData.gstNumber) {
        doc.fontSize(10).font('Helvetica-Bold').text(`GSTIN: ${invoiceData.gstNumber}`, { align: 'center' });
      }
      
      doc.moveDown(1);
      
      // Invoice details section
      doc.strokeColor('#ddd').lineWidth(1).moveTo(50, doc.y).lineTo(doc.page.width - 50, doc.y).stroke();
      doc.moveDown(0.5);
      
      // Two columns for client and invoice details
      const colWidth = (doc.page.width - 100) / 2;
      
      // Client details (left column)
      doc.fontSize(10).font('Helvetica-Bold').text('Bill To:', 50, doc.y);
      if (invoiceData.clientDetails) {
        doc.fontSize(10).font('Helvetica').text(invoiceData.clientDetails, 50, doc.y + 15, {
          width: colWidth - 10,
          height: 80
        });
      }
      
      // Invoice meta (right column)
      const rightColX = 50 + colWidth + 10;
      const metaStartY = doc.y - 15; // Align with "Bill To"
      
      doc.fontSize(10).font('Helvetica').text('Invoice Number:', rightColX, metaStartY);
      doc.fontSize(10).font('Helvetica-Bold').text(invoiceData.invoiceNumber, rightColX + 100, metaStartY, { align: 'right' });
      
      doc.fontSize(10).font('Helvetica').text('Invoice Date:', rightColX, metaStartY + 20);
      doc.fontSize(10).font('Helvetica').text(formatDate(invoiceData.issueDate), rightColX + 100, metaStartY + 20, { align: 'right' });
      
      doc.fontSize(10).font('Helvetica').text('Due Date:', rightColX, metaStartY + 40);
      doc.fontSize(10).font('Helvetica').text(formatDate(invoiceData.dueDate), rightColX + 100, metaStartY + 40, { align: 'right' });
      
      if (invoiceData.paymentTerms) {
        doc.fontSize(10).font('Helvetica').text('Payment Terms:', rightColX, metaStartY + 60);
        doc.fontSize(10).font('Helvetica').text(invoiceData.paymentTerms, rightColX + 100, metaStartY + 60, { align: 'right' });
      }
      
      // Move down to create space after the details section
      doc.moveDown(5);
      doc.strokeColor('#ddd').lineWidth(1).moveTo(50, doc.y).lineTo(doc.page.width - 50, doc.y).stroke();
      doc.moveDown(1);
      
      // Items table header
      const tableTop = doc.y;
      const tableColWidths = {
        sno: 30,
        desc: 190,
        hsn: 40,
        gst: 40,
        qty: 60,
        rate: 70,
        amount: 70
      };
      
      // Draw header
      doc.fontSize(9).font('Helvetica-Bold');
      doc.text('S.No', 50, tableTop);
      doc.text('Description', 50 + tableColWidths.sno, tableTop);
      doc.text('HSN', 50 + tableColWidths.sno + tableColWidths.desc, tableTop);
      doc.text('GST', 50 + tableColWidths.sno + tableColWidths.desc + tableColWidths.hsn, tableTop);
      doc.text('Quantity', 50 + tableColWidths.sno + tableColWidths.desc + tableColWidths.hsn + tableColWidths.gst, tableTop);
      doc.text('Rate', 50 + tableColWidths.sno + tableColWidths.desc + tableColWidths.hsn + tableColWidths.gst + tableColWidths.qty, tableTop);
      doc.text('Amount', 50 + tableColWidths.sno + tableColWidths.desc + tableColWidths.hsn + tableColWidths.gst + tableColWidths.qty + tableColWidths.rate, tableTop);
      
      // Draw line under header
      doc.moveDown(0.5);
      doc.strokeColor('#ddd').lineWidth(1).moveTo(50, doc.y).lineTo(doc.page.width - 50, doc.y).stroke();
      doc.moveDown(0.5);
      
      // Items rows
      doc.fontSize(9).font('Helvetica');
      
      if (invoiceData.items && invoiceData.items.length > 0) {
        invoiceData.items.forEach((item: any, index: number) => {
          const rowY = doc.y;
          
          // Ensure we don't run out of page space
          if (rowY > doc.page.height - 200) {
            doc.addPage();
            doc.y = 50; // Reset Y position on new page
          }
          
          doc.text(`${index + 1}`, 50, doc.y);
          doc.text(item.description || 'No description', 50 + tableColWidths.sno, doc.y, { width: tableColWidths.desc - 10 });
          doc.text('-', 50 + tableColWidths.sno + tableColWidths.desc, doc.y, { width: tableColWidths.hsn, align: 'center' });
          doc.text(`${gstRate}%`, 50 + tableColWidths.sno + tableColWidths.desc + tableColWidths.hsn, doc.y, { width: tableColWidths.gst, align: 'center' });
          doc.text(`${item.quantity} PCS`, 50 + tableColWidths.sno + tableColWidths.desc + tableColWidths.hsn + tableColWidths.gst, doc.y, { width: tableColWidths.qty, align: 'center' });
          doc.text(`₹${formatCurrency(item.rate)}`, 50 + tableColWidths.sno + tableColWidths.desc + tableColWidths.hsn + tableColWidths.gst + tableColWidths.qty, doc.y, { width: tableColWidths.rate, align: 'right' });
          doc.text(`₹${formatCurrency(item.amount)}`, 50 + tableColWidths.sno + tableColWidths.desc + tableColWidths.hsn + tableColWidths.gst + tableColWidths.qty + tableColWidths.rate, doc.y, { width: tableColWidths.amount, align: 'right' });
          
          doc.moveDown(1);
          doc.strokeColor('#f5f5f5').lineWidth(0.5).moveTo(50, doc.y - 5).lineTo(doc.page.width - 50, doc.y - 5).stroke();
        });
      } else {
        doc.text('No items', 50, doc.y, { width: pageWidth });
        doc.moveDown(1);
      }
      
      // Subtotal and calculations
      const calcX = doc.page.width - 200;
      doc.moveDown(1);
      
      doc.fontSize(9).font('Helvetica').text('Subtotal:', calcX, doc.y, { width: 80 });
      doc.text(`₹${formatCurrency(subtotal)}`, calcX + 100, doc.y, { width: 50, align: 'right' });
      doc.moveDown(0.5);
      
      if (invoiceData.discountTotal && invoiceData.discountTotal > 0) {
        doc.text(`Discount (${invoiceData.discountTotal}%):`, calcX, doc.y, { width: 80 });
        doc.text(`-₹${formatCurrency(discountAmount)}`, calcX + 100, doc.y, { width: 50, align: 'right' });
        doc.moveDown(0.5);
      }
      
      doc.text('Taxable Amount:', calcX, doc.y, { width: 80 });
      doc.text(`₹${formatCurrency(taxableAmount)}`, calcX + 100, doc.y, { width: 50, align: 'right' });
      doc.moveDown(0.5);
      
      // GST details
      if (isIntraState) {
        doc.text(`CGST (${cgstRate}%):`, calcX, doc.y, { width: 80 });
        doc.text(`₹${formatCurrency(cgstValue)}`, calcX + 100, doc.y, { width: 50, align: 'right' });
        doc.moveDown(0.5);
        
        doc.text(`SGST (${sgstRate}%):`, calcX, doc.y, { width: 80 });
        doc.text(`₹${formatCurrency(sgstValue)}`, calcX + 100, doc.y, { width: 50, align: 'right' });
        doc.moveDown(0.5);
      } else {
        doc.text(`IGST (${igstRate}%):`, calcX, doc.y, { width: 80 });
        doc.text(`₹${formatCurrency(igstValue)}`, calcX + 100, doc.y, { width: 50, align: 'right' });
        doc.moveDown(0.5);
      }
      
      if (invoiceData.shipping && invoiceData.shipping > 0) {
        doc.text('Shipping:', calcX, doc.y, { width: 80 });
        doc.text(`₹${formatCurrency(invoiceData.shipping)}`, calcX + 100, doc.y, { width: 50, align: 'right' });
        doc.moveDown(0.5);
      }
      
      // Total
      doc.strokeColor('#ddd').lineWidth(1).moveTo(calcX, doc.y).lineTo(doc.page.width - 50, doc.y).stroke();
      doc.moveDown(0.5);
      doc.fontSize(10).font('Helvetica-Bold').text('Total:', calcX, doc.y, { width: 80 });
      doc.text(`₹${formatCurrency(total)}`, calcX + 100, doc.y, { width: 50, align: 'right' });
      doc.moveDown(1);
      
      // Amount in words
      doc.strokeColor('#ddd').lineWidth(1).moveTo(50, doc.y).lineTo(doc.page.width - 50, doc.y).stroke();
      doc.moveDown(0.5);
      doc.fontSize(9).font('Helvetica-Bold').text('Amount in Words:', 50, doc.y);
      doc.font('Helvetica').text(amountInWords, 150, doc.y, { width: 350 });
      doc.moveDown(0.5);
      doc.strokeColor('#ddd').lineWidth(1).moveTo(50, doc.y).lineTo(doc.page.width - 50, doc.y).stroke();
      doc.moveDown(1);
      
      // GST summary table
      doc.fontSize(10).font('Helvetica-Bold').text('GST Summary:', 50, doc.y);
      doc.moveDown(0.5);
      
      // Set up GST table
      if (isIntraState) {
        // CGST + SGST table (Intra-state)
        const gstTableTop = doc.y;
        const gstColWidth = (pageWidth) / 7;
        
        // Table header
        doc.fontSize(8).font('Helvetica-Bold')
          .rect(50, gstTableTop, pageWidth, 25).fill('#f5f5f5').stroke('#ddd')
          .fillColor('#000'); // Reset fill color
          
        doc.text('HSN/SAC', 55, gstTableTop + 7, { width: gstColWidth - 5 });
        doc.text('Taxable Value', 55 + gstColWidth * 1, gstTableTop + 7, { width: gstColWidth - 5, align: 'center' });
        doc.text('Central Tax', 55 + gstColWidth * 2, gstTableTop + 7, { width: gstColWidth * 2 - 5, align: 'center' });
        doc.text('State/UT Tax', 55 + gstColWidth * 4, gstTableTop + 7, { width: gstColWidth * 2 - 5, align: 'center' });
        doc.text('Total Tax', 55 + gstColWidth * 6, gstTableTop + 7, { width: gstColWidth - 5, align: 'center' });
        
        // Sub-header for rates
        doc.text('Rate', 55 + gstColWidth * 2, gstTableTop + 15, { width: gstColWidth - 5, align: 'center' });
        doc.text('Amount', 55 + gstColWidth * 3, gstTableTop + 15, { width: gstColWidth - 5, align: 'center' });
        doc.text('Rate', 55 + gstColWidth * 4, gstTableTop + 15, { width: gstColWidth - 5, align: 'center' });
        doc.text('Amount', 55 + gstColWidth * 5, gstTableTop + 15, { width: gstColWidth - 5, align: 'center' });
        
        // Table row
        doc.fontSize(8).font('Helvetica')
          .rect(50, gstTableTop + 25, pageWidth, 20).stroke('#ddd');
          
        doc.text('-', 55, gstTableTop + 32, { width: gstColWidth - 5 });
        doc.text(`₹${formatCurrency(taxableAmount)}`, 55 + gstColWidth * 1, gstTableTop + 32, { width: gstColWidth - 5, align: 'right' });
        doc.text(`${cgstRate}%`, 55 + gstColWidth * 2, gstTableTop + 32, { width: gstColWidth - 5, align: 'center' });
        doc.text(`₹${formatCurrency(cgstValue)}`, 55 + gstColWidth * 3, gstTableTop + 32, { width: gstColWidth - 5, align: 'right' });
        doc.text(`${sgstRate}%`, 55 + gstColWidth * 4, gstTableTop + 32, { width: gstColWidth - 5, align: 'center' });
        doc.text(`₹${formatCurrency(sgstValue)}`, 55 + gstColWidth * 5, gstTableTop + 32, { width: gstColWidth - 5, align: 'right' });
        doc.text(`₹${formatCurrency(cgstValue + sgstValue)}`, 55 + gstColWidth * 6, gstTableTop + 32, { width: gstColWidth - 5, align: 'right' });
        
        // Total row
        doc.fontSize(8).font('Helvetica-Bold')
          .rect(50, gstTableTop + 45, pageWidth, 20).stroke('#ddd');
          
        doc.text('TOTAL', 55, gstTableTop + 52, { width: gstColWidth - 5, align: 'center' });
        doc.text(`₹${formatCurrency(taxableAmount)}`, 55 + gstColWidth * 1, gstTableTop + 52, { width: gstColWidth - 5, align: 'right' });
        doc.text(`₹${formatCurrency(cgstValue)}`, 55 + gstColWidth * 3, gstTableTop + 52, { width: gstColWidth - 5, align: 'right' });
        doc.text(`₹${formatCurrency(sgstValue)}`, 55 + gstColWidth * 5, gstTableTop + 52, { width: gstColWidth - 5, align: 'right' });
        doc.text(`₹${formatCurrency(cgstValue + sgstValue)}`, 55 + gstColWidth * 6, gstTableTop + 52, { width: gstColWidth - 5, align: 'right' });
        
        doc.moveDown(4);
      } else {
        // IGST table (Inter-state)
        const gstTableTop = doc.y;
        const gstColWidth = (pageWidth) / 5;
        
        // Table header
        doc.fontSize(8).font('Helvetica-Bold')
          .rect(50, gstTableTop, pageWidth, 25).fill('#f5f5f5').stroke('#ddd')
          .fillColor('#000'); // Reset fill color
          
        doc.text('HSN/SAC', 55, gstTableTop + 7, { width: gstColWidth - 5 });
        doc.text('Taxable Value', 55 + gstColWidth * 1, gstTableTop + 7, { width: gstColWidth - 5, align: 'center' });
        doc.text('Integrated Tax', 55 + gstColWidth * 2, gstTableTop + 7, { width: gstColWidth * 2 - 5, align: 'center' });
        doc.text('Total Tax', 55 + gstColWidth * 4, gstTableTop + 7, { width: gstColWidth - 5, align: 'center' });
        
        // Sub-header for rates
        doc.text('Rate', 55 + gstColWidth * 2, gstTableTop + 15, { width: gstColWidth - 5, align: 'center' });
        doc.text('Amount', 55 + gstColWidth * 3, gstTableTop + 15, { width: gstColWidth - 5, align: 'center' });
        
        // Table row
        doc.fontSize(8).font('Helvetica')
          .rect(50, gstTableTop + 25, pageWidth, 20).stroke('#ddd');
          
        doc.text('-', 55, gstTableTop + 32, { width: gstColWidth - 5 });
        doc.text(`₹${formatCurrency(taxableAmount)}`, 55 + gstColWidth * 1, gstTableTop + 32, { width: gstColWidth - 5, align: 'right' });
        doc.text(`${igstRate}%`, 55 + gstColWidth * 2, gstTableTop + 32, { width: gstColWidth - 5, align: 'center' });
        doc.text(`₹${formatCurrency(igstValue)}`, 55 + gstColWidth * 3, gstTableTop + 32, { width: gstColWidth - 5, align: 'right' });
        doc.text(`₹${formatCurrency(igstValue)}`, 55 + gstColWidth * 4, gstTableTop + 32, { width: gstColWidth - 5, align: 'right' });
        
        // Total row
        doc.fontSize(8).font('Helvetica-Bold')
          .rect(50, gstTableTop + 45, pageWidth, 20).stroke('#ddd');
          
        doc.text('TOTAL', 55, gstTableTop + 52, { width: gstColWidth - 5, align: 'center' });
        doc.text(`₹${formatCurrency(taxableAmount)}`, 55 + gstColWidth * 1, gstTableTop + 52, { width: gstColWidth - 5, align: 'right' });
        doc.text(`₹${formatCurrency(igstValue)}`, 55 + gstColWidth * 3, gstTableTop + 52, { width: gstColWidth - 5, align: 'right' });
        doc.text(`₹${formatCurrency(igstValue)}`, 55 + gstColWidth * 4, gstTableTop + 52, { width: gstColWidth - 5, align: 'right' });
        
        doc.moveDown(4);
      }
      
      // Payment and signature
      doc.fontSize(9).font('Helvetica').text('Payment Method:', 50, doc.y);
      doc.text(invoiceData.paymentMethod || 'Not specified', 150, doc.y);
      doc.moveDown(1);
      
      doc.fontSize(9).font('Helvetica-Bold').text('Bank Details:', 50, doc.y);
      doc.fontSize(9).font('Helvetica').text('Account Name: Your Account Name', 150, doc.y);
      doc.text('Account Number: XXXXXXXXXXXX', 150, doc.y + 12);
      doc.text('IFSC Code: XXXXX0000000', 150, doc.y + 12);
      doc.text('Bank Name: XXXX Bank', 150, doc.y + 12);
      doc.moveDown(1);
      
      // UPI details
      doc.fontSize(9).font('Helvetica').text('UPI: your.upi@provider', 150, doc.y);
      doc.moveDown(2);
      
      // Terms and signature
      doc.fontSize(9).font('Helvetica-Bold').text('Terms & Conditions:', 50, doc.y);
      doc.fontSize(8).font('Helvetica');
      doc.text('1. Payment is due within the specified terms.', 50, doc.y + 10);
      doc.text('2. This is a computer-generated invoice and does not require a signature.', 50, doc.y + 10);
      doc.moveDown(2);
      
      // Signature
      doc.fontSize(9).font('Helvetica-Bold').text('For ' + businessName, doc.page.width - 150, doc.y - 40, { align: 'right' });
      doc.moveDown(2);
      doc.fontSize(9).font('Helvetica-Bold').text('Authorized Signatory', doc.page.width - 150, doc.y, { align: 'right' });
      
      // Footer
      const footerY = doc.page.height - 50;
      doc.strokeColor('#ddd').lineWidth(1).moveTo(50, footerY).lineTo(doc.page.width - 50, footerY).stroke();
      doc.fontSize(8).font('Helvetica').text('This is a computer-generated invoice. No signature required.', 0, footerY + 10, { align: 'center' });
      
      // Finalize PDF
      doc.end();
    } catch (error) {
      console.error('Error generating PDF:', error);
      reject(new Error('Failed to generate PDF'));
    }
  });
}