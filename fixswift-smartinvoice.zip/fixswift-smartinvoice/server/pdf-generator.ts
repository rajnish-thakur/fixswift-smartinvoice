import PDFDocument from 'pdfkit';
import { format } from 'date-fns';

// Helper function to convert number to words (for Indian Rupees)
function numberToWords(num: number): string {
  const single = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const double = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  const formatTens = (num: number): string => {
    if (num < 10) return single[num];
    if (num < 20) return double[num - 10];
    return tens[Math.floor(num / 10)] + (num % 10 !== 0 ? ' ' + single[num % 10] : '');
  };

  if (num === 0) return 'Zero';
  
  // Handle lakhs and crores (Indian number system)
  let words = '';
  if (num >= 10000000) { // Crore
    words += formatTens(Math.floor(num / 10000000)) + ' Crore ';
    num %= 10000000;
  }
  if (num >= 100000) { // Lakh
    words += formatTens(Math.floor(num / 100000)) + ' Lakh ';
    num %= 100000;
  }
  if (num >= 1000) { // Thousand
    words += formatTens(Math.floor(num / 1000)) + ' Thousand ';
    num %= 1000;
  }
  if (num >= 100) { // Hundred
    words += formatTens(Math.floor(num / 100)) + ' Hundred ';
    num %= 100;
  }
  if (num > 0) {
    words += formatTens(num);
  }
  
  return words.trim();
}

// Helper function to format currency
const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount).replace('₹', '').trim();
};

// Format date for invoice
const formatDate = (date: string | Date): string => {
  if (!date) return '';
  
  try {
    if (typeof date === 'string') {
      return format(new Date(date), 'dd MMM yyyy');
    }
    return format(date, 'dd MMM yyyy');
  } catch (error) {
    return '';
  }
};

// Generate a modern PDF invoice using PDFKit
export async function generateInvoicePdf(invoiceData: any): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      // Create a PDF document
      const doc = new PDFDocument({
        size: 'A4',
        margins: { top: 0, bottom: 0, left: 0, right: 0 }
      });
      
      // Capture PDF data to buffer
      const buffers: Buffer[] = [];
      doc.on('data', (chunk) => {
        buffers.push(chunk);
      });
      
      doc.on('end', () => {
        const pdfData = Buffer.concat(buffers);
        resolve(pdfData);
      });
      
      // Define styling colors
      const primaryColor = '#3498db'; // Blue theme color
      const secondaryColor = '#f1f5f9'; // Light gray background
      const textColor = '#333333';
      const lightTextColor = '#666666';
      
      const pageWidth = doc.page.width;
      const contentWidth = pageWidth - 80; // 40px margin on each side
      const startX = 40;
      
      // Calculate values for the invoice
      const subtotal = invoiceData.subtotal || 0;
      let taxValue = 0;
      
      // GST calculations for internal use
      const isIntraState = invoiceData.gstType === 'cgst_sgst';
      const gstRate = invoiceData.gstRate || 0;
      
      // Calculate tax value based on GST type
      if (isIntraState) {
        // CGST + SGST (intra-state)
        const cgstValue = invoiceData.cgstValue || 0;
        const sgstValue = invoiceData.sgstValue || 0;
        taxValue = cgstValue + sgstValue;
      } else {
        // IGST (inter-state)
        taxValue = invoiceData.igstValue || 0;
      }
      
      // Get total 
      const total = invoiceData.total || (subtotal + taxValue);
      
      // Draw header section with dark colored background
      doc.fillColor('#333333')
         .rect(0, 0, pageWidth, 130)
         .fill();
      
      // Draw curved corner at the top left
      doc.save()
         .moveTo(0, 130)
         .lineTo(0, 90)
         .quadraticCurveTo(0, 80, 10, 80)
         .lineTo(40, 80)
         .lineTo(40, 130)
         .fillColor('#ffffff')
         .fill()
         .restore();
      
      // Draw blue strip on the left side of the header
      doc.save()
         .rect(40, 80, 40, 50)
         .fillColor(primaryColor)
         .fill()
         .restore();
      
      // Get business name from the data
      const businessNameLines = invoiceData.businessDetails?.split('\n') || [];
      const businessName = businessNameLines[0] || 'Company Name';
      const businessTagline = businessNameLines[1] || 'TAGLINE HERE';
      
      // Company logo and name
      doc.fillColor('#ffffff')
         .fontSize(24)
         .font('Helvetica-Bold')
         .text('INVOICE', 50, 40)
         .fontSize(12)
         .text(businessName, pageWidth - 190, 40)
         .font('Helvetica')
         .fontSize(8)
         .text(businessTagline, pageWidth - 190, 60);
      
      // Invoice details
      const infoStartY = 90;
      doc.fillColor(textColor)
         .font('Helvetica-Bold')
         .fontSize(9)
         .text('Account No', 90, infoStartY)
         .text(':', 170, infoStartY)
         .font('Helvetica')
         .text(invoiceData.gstNumber || '0123456789', 180, infoStartY)
         
         .font('Helvetica-Bold')
         .text('Invoice No', 90, infoStartY + 20)
         .text(':', 170, infoStartY + 20)
         .font('Helvetica')
         .text(invoiceData.invoiceNumber || 'INV-001', 180, infoStartY + 20)
         
         .font('Helvetica-Bold')
         .text('Invoice Date', 90, infoStartY + 40)
         .text(':', 170, infoStartY + 40)
         .font('Helvetica')
         .text(formatDate(invoiceData.issueDate || new Date()), 180, infoStartY + 40);
      
      // Table header with colored background
      const tableStartY = 160;
      doc.roundedRect(startX, tableStartY, contentWidth, 30, 3)
         .fillColor(primaryColor)
         .fill();
      
      // Table header text
      doc.fillColor('#ffffff')
         .font('Helvetica-Bold')
         .fontSize(10)
         .text('SL', 60, tableStartY + 10)
         .text('Item Description', 100, tableStartY + 10)
         .text('Price', 310, tableStartY + 10, { width: 70, align: 'right' })
         .text('Qty.', 400, tableStartY + 10, { width: 40, align: 'right' })
         .text('Total', 460, tableStartY + 10, { width: 80, align: 'right' });
      
      // Table rows
      let rowY = tableStartY + 40;
      const rowHeight = 25;
      
      if (invoiceData.items && invoiceData.items.length > 0) {
        invoiceData.items.forEach((item: any, index: number) => {
          const itemPrice = item.rate || 0;
          const itemQty = item.quantity || 0;
          const itemTotal = item.amount || (itemPrice * itemQty);
          
          doc.fillColor(textColor)
             .font('Helvetica')
             .fontSize(10)
             .text((index + 1).toString(), 60, rowY)
             .text(item.description || 'Product Description', 100, rowY)
             .text(`₹${itemPrice.toFixed(2)}`, 310, rowY, { width: 70, align: 'right' })
             .text(itemQty.toString(), 400, rowY, { width: 40, align: 'right' })
             .text(`₹${itemTotal.toFixed(2)}`, 460, rowY, { width: 80, align: 'right' });
          
          rowY += rowHeight;
          
          // Add a light separator line
          if (index < invoiceData.items.length - 1) {
            doc.strokeColor('#eeeeee')
               .lineWidth(1)
               .moveTo(startX, rowY - 5)
               .lineTo(startX + contentWidth, rowY - 5)
               .stroke();
          }
        });
      } else {
        doc.fillColor(textColor)
           .font('Helvetica')
           .fontSize(10)
           .text('No items', 100, rowY);
        
        rowY += rowHeight;
      }
      
      // Summary section
      const summaryStartY = rowY + 20;
      const summaryLabelX = 350;
      const summaryValueX = 530;
      
      // Subtotal
      doc.font('Helvetica')
         .text('Subtotal', summaryLabelX, summaryStartY, { width: 100, align: 'right' })
         .text(`₹${subtotal.toFixed(2)}`, summaryValueX, summaryStartY, { width: 0, align: 'right' });
      
      // Tax rate with GST label
      const taxLabel = isIntraState ? 
        `CGST+SGST (${gstRate}%)` : 
        `IGST (${gstRate}%)`;
      
      doc.text(taxLabel, summaryLabelX, summaryStartY + 25, { width: 100, align: 'right' })
         .text(`₹${taxValue.toFixed(2)}`, summaryValueX, summaryStartY + 25, { width: 0, align: 'right' });
      
      // Total with colored background
      doc.roundedRect(summaryLabelX - 20, summaryStartY + 50, 200, 30, 3)
         .fillColor(primaryColor)
         .fill();
      
      doc.fillColor('#ffffff')
         .font('Helvetica-Bold')
         .text('TOTAL', summaryLabelX, summaryStartY + 58, { width: 100, align: 'right' })
         .text(`₹${total.toFixed(2)}`, summaryValueX, summaryStartY + 58, { width: 0, align: 'right' });
      
      // Amount in words
      doc.fillColor(textColor)
         .font('Helvetica')
         .fontSize(9)
         .text(`Amount in words: ${numberToWords(Math.round(total))} Rupees Only`, 50, summaryStartY + 90, { width: 500 });
      
      // Notes section
      doc.fillColor(textColor)
         .font('Helvetica-Bold')
         .fontSize(11)
         .text('Note:', 50, summaryStartY + 120);
      
      doc.lineWidth(0.5)
         .moveTo(50, summaryStartY + 140)
         .lineTo(300, summaryStartY + 140)
         .moveTo(50, summaryStartY + 160)
         .lineTo(300, summaryStartY + 160)
         .moveTo(50, summaryStartY + 180)
         .lineTo(300, summaryStartY + 180)
         .stroke();
      
      // Signature section with business owner name or default
      const signatureY = summaryStartY + 140;
      const signerName = businessNameLines.length > 0 ? businessName.split(' ')[0] + ' Smeeth' : 'John Smeeth';
      
      doc.font('Helvetica-Bold')
         .fontSize(12)
         .fillColor(primaryColor)
         .text(signerName, 400, signatureY, { align: 'center' })
         .font('Helvetica')
         .fontSize(10)
         .fillColor(textColor)
         .text('Manager', 400, signatureY + 15, { align: 'center' });
      
      // Footer with contact information
      const footerY = doc.page.height - 70;
      
      doc.rect(0, footerY, pageWidth, 70)
         .fillColor(primaryColor)
         .fill();
      
      // QR code placeholder (would need to generate actual QR in a production app)
      doc.rect(50, footerY + 10, 50, 50)
         .fillColor('#ffffff')
         .fill();
      
      // Extract address and contact details from business details if available
      let addressLine1 = 'Office street name here';
      let addressLine2 = 'Office house name here';
      let contactLine = 'Office mail here';
      
      if (businessNameLines.length > 2) {
        addressLine1 = businessNameLines[2] || addressLine1;
      }
      if (businessNameLines.length > 3) {
        addressLine2 = businessNameLines[3] || addressLine2;
      }
      if (businessNameLines.length > 4) {
        contactLine = businessNameLines[4] || contactLine;
      }
      
      // Contact information
      doc.fillColor('#ffffff')
         .font('Helvetica-Bold')
         .fontSize(10)
         .text('GET IN TOUCH', 120, footerY + 15)
         .font('Helvetica')
         .fontSize(8)
         .text(addressLine1, 120, footerY + 30)
         .text(addressLine2, 120, footerY + 40)
         .text(contactLine, 120, footerY + 50);
      
      // Finalize PDF file
      doc.end();
    } catch (error) {
      console.error('Error generating PDF:', error);
      reject(new Error('Failed to generate PDF'));
    }
  });
}