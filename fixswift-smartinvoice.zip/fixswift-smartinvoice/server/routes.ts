import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { invoiceInsertSchema } from "@shared/schema";
import multer from "multer";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { generateInvoicePdf } from "./pdf-generator";

// Set up multer for file uploads
const upload = multer({
  limits: {
    fileSize: 2 * 1024 * 1024, // 2MB
  },
  storage: multer.memoryStorage(),
  fileFilter: (req, file, cb) => {
    // Accept only image files
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed"));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  const apiPrefix = "/api";

  // Get all invoices
  app.get(`${apiPrefix}/invoices`, async (req, res) => {
    try {
      const invoices = await storage.getAllInvoices();
      res.json(invoices);
    } catch (error) {
      console.error("Error fetching invoices:", error);
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Get invoice by ID
  app.get(`${apiPrefix}/invoices/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid invoice ID" });
      }

      const invoice = await storage.getInvoiceById(id);
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      res.json(invoice);
    } catch (error) {
      console.error(`Error fetching invoice ${req.params.id}:`, error);
      res.status(500).json({ message: "Failed to fetch invoice" });
    }
  });

  // Create a new invoice
  app.post(
    `${apiPrefix}/invoices`,
    upload.single("logo"),
    async (req, res) => {
      try {
        const { 
          invoiceNumber, 
          paymentTerms, 
          issueDate, 
          dueDate, 
          currency,
          businessDetails,
          clientDetails,
          subtotal,
          discountTotal,
          gstNumber,
          gstType,
          gstRate,
          cgstValue,
          sgstValue,
          igstValue,
          shipping,
          total,
          paymentMethod,
          items
        } = req.body;

        // Prepare data for validation
        const invoiceData = {
          invoiceNumber,
          paymentTerms,
          issueDate: new Date(issueDate),
          dueDate: new Date(dueDate),
          currency,
        };

        // Process logo if uploaded
        let logoData;
        if (req.file) {
          // Convert the buffer to a base64 string
          logoData = `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`;
        }

        // Validate the input data
        try {
          invoiceInsertSchema.parse(invoiceData);
        } catch (validationError) {
          if (validationError instanceof z.ZodError) {
            const readableError = fromZodError(validationError);
            return res.status(400).json({ message: readableError.message });
          }
          return res.status(400).json({ message: "Invalid invoice data" });
        }

        // Parse items if sent as a string
        let parsedItems;
        if (items && typeof items === 'string') {
          try {
            parsedItems = JSON.parse(items);
          } catch (e) {
            console.error("Error parsing items JSON:", e);
            parsedItems = [];
          }
        } else {
          parsedItems = items || [];
        }

        // Create the invoice
        const invoice = await storage.createInvoice({
          ...invoiceData,
          logo: logoData,
          businessDetails,
          clientDetails,
          subtotal,
          discountTotal,
          gstNumber,
          gstType,
          gstRate,
          cgstValue,
          sgstValue,
          igstValue,
          shipping,
          total,
          paymentMethod,
          items: parsedItems
        });

        res.status(201).json(invoice);
      } catch (error) {
        console.error("Error creating invoice:", error);
        res.status(500).json({ message: "Failed to create invoice" });
      }
    }
  );

  // Update an invoice
  app.put(
    `${apiPrefix}/invoices/:id`,
    upload.single("logo"),
    async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        if (isNaN(id)) {
          return res.status(400).json({ message: "Invalid invoice ID" });
        }

        const { 
          invoiceNumber, 
          paymentTerms, 
          issueDate, 
          dueDate, 
          currency,
          businessDetails,
          clientDetails,
          subtotal,
          discountTotal,
          gstNumber,
          gstType,
          gstRate,
          cgstValue,
          sgstValue,
          igstValue,
          shipping,
          total,
          paymentMethod,
          items
        } = req.body;

        // Prepare data for update
        const invoiceData: any = {
          invoiceNumber,
          paymentTerms,
          currency,
          businessDetails,
          clientDetails,
          subtotal,
          discountTotal,
          gstNumber,
          gstType,
          gstRate,
          cgstValue,
          sgstValue,
          igstValue,
          shipping,
          total,
          paymentMethod
        };

        // Handle dates if provided
        if (issueDate) {
          invoiceData.issueDate = new Date(issueDate);
        }
        if (dueDate) {
          invoiceData.dueDate = new Date(dueDate);
        }

        // Process logo if uploaded
        if (req.file) {
          invoiceData.logo = `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`;
        }
        
        // Parse items if sent as a string
        if (items) {
          if (typeof items === 'string') {
            try {
              invoiceData.items = JSON.parse(items);
            } catch (e) {
              console.error("Error parsing items JSON:", e);
              invoiceData.items = [];
            }
          } else {
            invoiceData.items = items;
          }
        }

        const invoice = await storage.updateInvoice(id, invoiceData);
        if (!invoice) {
          return res.status(404).json({ message: "Invoice not found" });
        }

        res.json(invoice);
      } catch (error) {
        console.error(`Error updating invoice ${req.params.id}:`, error);
        res.status(500).json({ message: "Failed to update invoice" });
      }
    }
  );

  // Delete an invoice
  app.delete(`${apiPrefix}/invoices/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid invoice ID" });
      }

      const invoice = await storage.deleteInvoice(id);
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      res.json({ message: "Invoice deleted successfully" });
    } catch (error) {
      console.error(`Error deleting invoice ${req.params.id}:`, error);
      res.status(500).json({ message: "Failed to delete invoice" });
    }
  });
  
  // Download invoice as PDF
  app.get(`${apiPrefix}/invoices/:id/download`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid invoice ID" });
      }

      const invoice = await storage.getInvoiceById(id);
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      // Generate PDF from invoice data
      const pdfBuffer = await generateInvoicePdf(invoice);
      
      // Set headers for PDF download
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="invoice-${invoice.invoiceNumber}.pdf"`);
      
      // Send the PDF buffer
      res.send(pdfBuffer);
    } catch (error) {
      console.error(`Error generating PDF for invoice ${req.params.id}:`, error);
      res.status(500).json({ message: "Failed to generate invoice PDF" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
