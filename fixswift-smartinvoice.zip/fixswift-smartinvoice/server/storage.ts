import { db } from "@db";
import { invoices, type InsertInvoice } from "@shared/schema";
import { eq } from "drizzle-orm";

export const storage = {
  // Invoice operations
  async createInvoice(invoice: InsertInvoice) {
    try {
      const result = await db.insert(invoices).values(invoice).returning();
      return result[0];
    } catch (error) {
      console.error("Error creating invoice:", error);
      throw new Error("Failed to create invoice");
    }
  },

  async getInvoiceById(id: number) {
    try {
      const result = await db.query.invoices.findFirst({
        where: eq(invoices.id, id),
      });
      return result;
    } catch (error) {
      console.error(`Error getting invoice with id ${id}:`, error);
      throw new Error(`Failed to retrieve invoice with id ${id}`);
    }
  },

  async getAllInvoices() {
    try {
      const result = await db.query.invoices.findMany({
        orderBy: (invoices, { desc }) => [desc(invoices.createdAt)],
      });
      return result;
    } catch (error) {
      console.error("Error getting all invoices:", error);
      throw new Error("Failed to retrieve invoices");
    }
  },

  async updateInvoice(id: number, invoice: Partial<InsertInvoice>) {
    try {
      const result = await db
        .update(invoices)
        .set({ ...invoice, updatedAt: new Date() })
        .where(eq(invoices.id, id))
        .returning();
      return result[0];
    } catch (error) {
      console.error(`Error updating invoice with id ${id}:`, error);
      throw new Error(`Failed to update invoice with id ${id}`);
    }
  },

  async deleteInvoice(id: number) {
    try {
      const result = await db
        .delete(invoices)
        .where(eq(invoices.id, id))
        .returning();
      return result[0];
    } catch (error) {
      console.error(`Error deleting invoice with id ${id}:`, error);
      throw new Error(`Failed to delete invoice with id ${id}`);
    }
  },
};
