declare module 'html-pdf-node' {
  interface PdfOptions {
    format?: string;
    path?: string;
    width?: number | string;
    height?: number | string;
    margin?: {
      top?: string | number;
      right?: string | number;
      bottom?: string | number;
      left?: string | number;
    };
    printBackground?: boolean;
    landscape?: boolean;
    scale?: number;
    displayHeaderFooter?: boolean;
    headerTemplate?: string;
    footerTemplate?: string;
    pageRanges?: string;
    preferCSSPageSize?: boolean;
  }

  interface FileOptions {
    content?: string;
    path?: string;
    url?: string;
  }

  interface Module {
    generatePdf: (
      file: FileOptions,
      options?: PdfOptions
    ) => Promise<Buffer>;
    
    generatePdfs: (
      files: FileOptions[],
      options?: PdfOptions
    ) => Promise<Buffer[]>;
  }

  const module: Module;
  export default module;
}