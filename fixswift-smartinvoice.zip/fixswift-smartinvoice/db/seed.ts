import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    // Check if there are already invoices in the database
    const existingInvoices = await db.query.invoices.findMany({
      limit: 1
    });

    if (existingInvoices.length === 0) {
      console.log("Seeding invoices table...");
      
      const now = new Date();
      const dueDate = new Date(now);
      dueDate.setDate(now.getDate() + 15);
      
      // Insert a sample invoice
      await db.insert(schema.invoices).values({
        invoiceNumber: "INV-001",
        paymentTerms: "net15",
        issueDate: now,
        dueDate: dueDate,
        currency: "USD",
        createdAt: now,
        updatedAt: now
      });
      
      console.log("Seeded invoices table successfully!");
    } else {
      console.log("Invoices table already has data, skipping seed.");
    }
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
